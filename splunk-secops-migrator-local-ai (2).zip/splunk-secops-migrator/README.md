# 🛡️ Splunk → Google SecOps Migrator (100% Local, Free)

AI-powered migration tool using **Ollama** — runs entirely on your CPU/RAM.
No API key. No cloud. No cost.

---

## Quick Start (Ubuntu)

```bash
unzip splunk-secops-migrator.zip
cd splunk-secops-migrator
chmod +x scripts/setup_and_run.sh
./scripts/setup_and_run.sh
```

The script automatically:
- Detects your RAM and picks the right model
- Installs Ollama (local AI engine)
- Downloads the LLM model (~2–5 GB, one time)
- Sets up Python backend + React frontend
- Starts everything at **http://localhost:8000**

---

## RAM Requirements

| RAM    | Recommended Model | Download Size | Quality  |
|--------|------------------|--------------|---------|
| 4 GB   | `phi3`           | 2.3 GB       | Good    |
| 6 GB   | `llama3.2`       | 2.0 GB       | Good    |
| 8 GB+  | `mistral`        | 4.1 GB       | Best ✓  |
| 16 GB+ | `qwen2.5-coder`  | 4.7 GB       | Best for code |

---

## Manual Model Switch

Edit `backend/.env`:
```bash
OLLAMA_MODEL=mistral      # change to any model below
```

Pull a different model:
```bash
ollama pull phi3           # 2.3 GB, fast on low RAM
ollama pull llama3.2       # 2.0 GB, very fast
ollama pull mistral        # 4.1 GB, best quality
ollama pull gemma2         # 5.4 GB, Google model
ollama pull qwen2.5-coder  # 4.7 GB, best for code/YARA-L
```

---

## Dev Mode (hot reload)

```bash
# Terminal 1 — Ollama
ollama serve

# Terminal 2 — backend
cd backend && source venv/bin/activate && uvicorn app.main:app --reload

# Terminal 3 — frontend
cd frontend && npm run dev
# → http://localhost:5173
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET`  | `/api/health` | Health check |
| `GET`  | `/api/ollama/status` | Ollama + model status |
| `GET`  | `/api/ollama/recommended` | Recommended models |
| `POST` | `/api/migrate/` | Migrate single item |
| `POST` | `/api/migrate/file` | Upload .xml/.conf file |
| `POST` | `/api/batch/` | Batch migrate up to 20 items |
| `GET`  | `/api/history/` | Migration history |
| `GET`  | `/api/history/export/all` | Export all as JSON |

Swagger UI: **http://localhost:8000/docs**

---

## Performance Tips (CPU inference)

- **Increase timeout** if migrations time out: set `OLLAMA_TIMEOUT=600` in `.env`
- **Use a smaller model** on slow CPUs: `OLLAMA_MODEL=phi3`
- **Close other apps** to free RAM before running
- First request is slow (model loads into RAM); subsequent ones are faster
- On a modern 4-core CPU: mistral takes ~30–90s per migration

---

## Troubleshooting

**"Cannot connect to Ollama"**
→ Run `ollama serve` in a separate terminal

**"Model not pulled"**  
→ Run `ollama pull mistral` (or whichever model is in your .env)

**Migration times out**  
→ Increase `OLLAMA_TIMEOUT=600` in `backend/.env` and restart

**Out of memory**  
→ Switch to smaller model: `OLLAMA_MODEL=phi3` in `.env`
