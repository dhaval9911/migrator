import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 120000,
})

export const migrateContent = (content, migration_type, name) =>
  api.post('/migrate/', { content, migration_type, name }).then(r => r.data)

export const migrateFile = (file, migration_type, name) => {
  const form = new FormData()
  form.append('file', file)
  form.append('migration_type', migration_type)
  if (name) form.append('name', name)
  return api.post('/migrate/file', form, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }).then(r => r.data)
}

export const batchMigrate = (items) =>
  api.post('/batch/', { items }).then(r => r.data)

export const getHistory = (params = {}) =>
  api.get('/history/', { params }).then(r => r.data)

export const getMigration = (id) =>
  api.get(`/history/${id}`).then(r => r.data)

export const deleteMigration = (id) =>
  api.delete(`/history/${id}`).then(r => r.data)

export const exportAll = () =>
  api.get('/history/export/all').then(r => r.data)

export const healthCheck = () =>
  api.get('/health').then(r => r.data)

export default api

export const getOllamaStatus = () =>
  api.get('/ollama/status').then(r => r.data)

export const getRecommendedModels = () =>
  api.get('/ollama/recommended').then(r => r.data)
