import { useState, useEffect } from 'react'
import { healthCheck } from './utils/api'
import MigratePage from './pages/MigratePage'
import HistoryPage from './pages/HistoryPage'
import BatchPage from './pages/BatchPage'
import OllamaStatus from './components/OllamaStatus'

const NAV = [
  { id: 'migrate', label: '⚡ Migrate' },
  { id: 'batch',   label: '📦 Batch'   },
  { id: 'history', label: '📋 History' },
]

export default function App() {
  const [page, setPage] = useState('migrate')
  const [apiOnline, setApiOnline] = useState(null)
  const [sessionCount, setSessionCount] = useState(0)

  useEffect(() => {
    healthCheck()
      .then(() => setApiOnline(true))
      .catch(() => setApiOnline(false))
  }, [])

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', backgroundImage: 'radial-gradient(ellipse at 15% 0%, rgba(38,132,255,0.07) 0%, transparent 55%), radial-gradient(ellipse at 85% 100%, rgba(0,200,150,0.05) 0%, transparent 55%)' }}>
      <header style={{
        borderBottom: '1px solid var(--border)', padding: '0 28px', height: 60,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'rgba(10,13,18,0.97)', backdropFilter: 'blur(12px)',
        position: 'sticky', top: 0, zIndex: 100,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 800, letterSpacing: '-0.5px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: '#65a637' }}>splunk</span>
            <span style={{ color: '#444', fontSize: 18 }}>→</span>
            <span style={{ color: '#1a73e8' }}>secops</span>
            <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: '1.5px', textTransform: 'uppercase', padding: '3px 8px', borderRadius: 4, border: '1px solid var(--border2)', color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>LOCAL AI</span>
          </div>
          <nav style={{ display: 'flex', gap: 2 }}>
            {NAV.map(n => (
              <button key={n.id} onClick={() => setPage(n.id)} style={{
                padding: '6px 16px', borderRadius: 6, border: 'none', cursor: 'pointer',
                fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600,
                background: page === n.id ? 'var(--surface2)' : 'transparent',
                color: page === n.id ? 'var(--text)' : 'var(--muted)',
                transition: 'all 0.15s',
              }}>{n.label}</button>
            ))}
          </nav>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {sessionCount > 0 && <span style={{ fontSize: 11, color: 'var(--accent-green)' }}>{sessionCount} migrated</span>}
          <OllamaStatus />
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--muted)' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: apiOnline === null ? '#555' : apiOnline ? 'var(--accent-green)' : '#ff4d6d' }} />
            {apiOnline ? 'API' : apiOnline === null ? '...' : 'API offline'}
          </div>
        </div>
      </header>

      <main style={{ padding: '24px 28px', maxWidth: 1440, margin: '0 auto' }}>
        {page === 'migrate' && <MigratePage onMigrated={() => setSessionCount(n => n + 1)} />}
        {page === 'batch'   && <BatchPage   onMigrated={() => setSessionCount(n => n + 1)} />}
        {page === 'history' && <HistoryPage />}
      </main>
    </div>
  )
}
