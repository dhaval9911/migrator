import { useState, useEffect } from 'react'
import { getOllamaStatus, getRecommendedModels } from '../utils/api'

export default function OllamaStatus() {
  const [status, setStatus] = useState(null)
  const [recommended, setRecommended] = useState([])
  const [showPanel, setShowPanel] = useState(false)

  const refresh = async () => {
    try {
      const [s, r] = await Promise.all([getOllamaStatus(), getRecommendedModels()])
      setStatus(s)
      setRecommended(r.models || [])
    } catch (e) {
      setStatus({ running: false, error: e.message })
    }
  }

  useEffect(() => { refresh() }, [])

  if (!status) return null

  const dot = status.running && status.model_ready ? '#00c896'
    : status.running ? '#ffd166' : '#ff4d6d'

  const label = status.running && status.model_ready
    ? `${status.active_model} ready`
    : status.running ? `${status.active_model} not pulled`
    : 'Ollama offline'

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setShowPanel(v => !v)}
        style={{
          display: 'flex', alignItems: 'center', gap: 7,
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 6, padding: '5px 12px', cursor: 'pointer',
          fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text2)',
          transition: 'all 0.15s',
        }}
      >
        <div style={{ width: 7, height: 7, borderRadius: '50%', background: dot, boxShadow: `0 0 6px ${dot}` }} />
        🤖 {label}
      </button>

      {showPanel && (
        <div style={{
          position: 'absolute', right: 0, top: 36, zIndex: 200,
          background: 'var(--surface)', border: '1px solid var(--border2)',
          borderRadius: 10, padding: 16, width: 360,
          boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
        }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, marginBottom: 12, color: 'var(--text)' }}>
            🤖 Ollama — Local AI Engine
          </div>

          {!status.running && (
            <div style={{ background: 'rgba(255,77,109,0.1)', border: '1px solid rgba(255,77,109,0.25)', borderRadius: 7, padding: '10px 12px', marginBottom: 12, fontSize: 12, color: '#ff4d6d' }}>
              <strong>Ollama is not running.</strong><br />
              Run in a terminal: <code style={{ background: 'rgba(0,0,0,0.3)', padding: '1px 6px', borderRadius: 3 }}>ollama serve</code>
            </div>
          )}

          {status.running && !status.model_ready && (
            <div style={{ background: 'rgba(255,209,102,0.1)', border: '1px solid rgba(255,209,102,0.25)', borderRadius: 7, padding: '10px 12px', marginBottom: 12, fontSize: 12, color: 'var(--accent-yellow)' }}>
              <strong>Model not pulled.</strong><br />
              Run: <code style={{ background: 'rgba(0,0,0,0.3)', padding: '1px 6px', borderRadius: 3 }}>ollama pull {status.active_model}</code>
            </div>
          )}

          {status.running && status.model_ready && (
            <div style={{ background: 'rgba(0,200,150,0.08)', border: '1px solid rgba(0,200,150,0.2)', borderRadius: 7, padding: '10px 12px', marginBottom: 12, fontSize: 12, color: 'var(--accent-green)' }}>
              ✓ <strong>{status.active_model}</strong> is loaded and ready
            </div>
          )}

          {status.available_models?.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 6, fontFamily: 'var(--font-display)', fontWeight: 700 }}>Installed Models</div>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                {status.available_models.map(m => (
                  <span key={m} style={{
                    fontSize: 11, padding: '2px 8px', borderRadius: 4,
                    background: m.includes(status.active_model) ? 'rgba(0,200,150,0.12)' : 'var(--surface2)',
                    border: `1px solid ${m.includes(status.active_model) ? 'rgba(0,200,150,0.3)' : 'var(--border)'}`,
                    color: m.includes(status.active_model) ? 'var(--accent-green)' : 'var(--text2)',
                  }}>{m}</span>
                ))}
              </div>
            </div>
          )}

          <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 8, fontFamily: 'var(--font-display)', fontWeight: 700 }}>Recommended Models</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {recommended.map(m => (
              <div key={m.name} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, padding: '8px 10px', background: 'var(--surface2)', borderRadius: 6, border: `1px solid ${m.recommended ? 'rgba(38,132,255,0.3)' : 'var(--border)'}` }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: m.recommended ? 'var(--accent-blue)' : 'var(--text)', display: 'flex', alignItems: 'center', gap: 6 }}>
                    {m.name} {m.recommended && <span style={{ fontSize: 9, padding: '1px 5px', borderRadius: 3, background: 'rgba(38,132,255,0.15)', color: 'var(--accent-blue)', border: '1px solid rgba(38,132,255,0.3)', letterSpacing: '0.5px' }}>RECOMMENDED</span>}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{m.description}</div>
                  <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>Size: {m.size} · RAM: {m.ram}</div>
                </div>
                <code style={{ fontSize: 10, color: 'var(--text2)', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: 3, whiteSpace: 'nowrap', alignSelf: 'center' }}>ollama pull {m.name}</code>
              </div>
            ))}
          </div>

          <button onClick={refresh} style={{ marginTop: 12, width: '100%', padding: '7px', borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, background: 'var(--surface2)', border: '1px solid var(--border2)', color: 'var(--text2)' }}>
            ↻ Refresh Status
          </button>
        </div>
      )}
    </div>
  )
}
