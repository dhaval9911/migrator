export default function PreprocessorInsights({ preprocessor }) {
  if (!preprocessor) return null
  const { udm_field_mappings, unmapped_fields, log_types } = preprocessor
  const hasMappings = udm_field_mappings && Object.keys(udm_field_mappings).length > 0

  if (!hasMappings && !unmapped_fields?.length && !log_types?.length) return null

  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10,
      overflow: 'hidden', marginBottom: 14,
    }}>
      <div style={{ padding: '10px 16px', background: 'var(--surface2)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '1.2px', textTransform: 'uppercase', color: 'var(--text2)' }}>
          🔍 Pre-Processor Analysis
        </span>
        <span style={{ fontSize: 10, color: 'var(--muted)' }}>— field mappings resolved before LLM call</span>
      </div>
      <div style={{ padding: '12px 16px', display: 'flex', gap: 24, flexWrap: 'wrap' }}>
        {hasMappings && (
          <div>
            <div style={{ fontSize: 10, color: 'var(--accent-green)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>
              ✓ Mapped Fields ({Object.keys(udm_field_mappings).length})
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {Object.entries(udm_field_mappings).map(([spl, udm]) => (
                <div key={spl} style={{ fontSize: 11, fontFamily: 'var(--font-mono)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ color: 'var(--splunk)', minWidth: 120 }}>{spl}</span>
                  <span style={{ color: 'var(--muted)' }}>→</span>
                  <span style={{ color: 'var(--accent-blue)' }}>{udm}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        {unmapped_fields?.length > 0 && (
          <div>
            <div style={{ fontSize: 10, color: 'var(--accent-yellow)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>
              ⚠ Unmapped Fields ({unmapped_fields.length})
            </div>
            <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
              {unmapped_fields.map(f => (
                <span key={f} style={{ fontSize: 11, padding: '2px 8px', borderRadius: 4, background: 'rgba(255,209,102,0.1)', border: '1px solid rgba(255,209,102,0.2)', color: 'var(--accent-yellow)', fontFamily: 'var(--font-mono)' }}>{f}</span>
              ))}
            </div>
            <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 4 }}>Manual UDM mapping needed</div>
          </div>
        )}
        {log_types?.length > 0 && (
          <div>
            <div style={{ fontSize: 10, color: 'var(--accent-blue)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>
              📋 UDM Log Types
            </div>
            <div style={{ display: 'flex', gap: 5 }}>
              {log_types.map(lt => (
                <span key={lt} style={{ fontSize: 11, padding: '2px 10px', borderRadius: 4, background: 'rgba(38,132,255,0.1)', border: '1px solid rgba(38,132,255,0.2)', color: 'var(--accent-blue)', fontFamily: 'var(--font-mono)' }}>{lt}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
