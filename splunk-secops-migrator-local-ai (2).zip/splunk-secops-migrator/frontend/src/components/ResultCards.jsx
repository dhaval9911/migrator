import { useState } from 'react'
import PreprocessorInsights from './PreprocessorInsights'

function syntaxHL(code, type) {
  if (!code) return ''
  let h = String(code).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  if (type === 'yaral') {
    h = h.replace(/\b(rule|meta|events|condition|match|over|where|outcome|and|or|not|all|any|nocase|strings)\b/g,'<span style="color:#c792ea">$1</span>')
         .replace(/"([^"]*)"/g,'<span style="color:#c3e88d">"$1"</span>')
         .replace(/\/\/.*/g,'<span style="color:#546e7a;font-style:italic">$&</span>')
         .replace(/\b(\$[a-zA-Z_][a-zA-Z0-9_.]*)/g,'<span style="color:#ffcb6b">$1</span>')
         .replace(/\b(\d+)\b/g,'<span style="color:#f78c6c">$1</span>')
  } else if (type === 'udm') {
    h = h.replace(/\b(events|match|over|where|condition|outcome|and|or|not|all|any)\b/g,'<span style="color:#c792ea">$1</span>')
         .replace(/\b(target|principal|src|network|security_result|metadata|about|observer)\b/g,'<span style="color:#82aaff">$1</span>')
         .replace(/"([^"]*)"/g,'<span style="color:#c3e88d">"$1"</span>')
         .replace(/\/\/.*/g,'<span style="color:#546e7a;font-style:italic">$&</span>')
         .replace(/\b(\$[a-zA-Z_][a-zA-Z0-9_.]*)/g,'<span style="color:#ffcb6b">$1</span>')
  } else if (type === 'json') {
    h = h.replace(/"([^"]+)":/g,'<span style="color:#ffcb6b">"$1"</span>:')
         .replace(/: "([^"]*)"/g,': <span style="color:#c3e88d">"$1"</span>')
         .replace(/: (\d+)/g,': <span style="color:#f78c6c">$1</span>')
         .replace(/: (true|false|null)/g,': <span style="color:#c792ea">$1</span>')
  }
  return h
}

function copyText(text) { navigator.clipboard.writeText(text) }

function downloadFile(content, filename) {
  const blob = new Blob([content], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}

function CodeCard({ title, badge, badgeColor, content, type, downloadName }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    copyText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 16px', background: 'var(--surface2)', borderBottom: '1px solid var(--border)' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '1.2px', textTransform: 'uppercase', color: 'var(--text2)' }}>{title}</div>
        <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 4, fontWeight: 700, letterSpacing: '0.5px', background: badgeColor.bg, color: badgeColor.text, border: `1px solid ${badgeColor.border}` }}>{badge}</span>
      </div>
      <div
        dangerouslySetInnerHTML={{ __html: syntaxHL(content, type) }}
        style={{ padding: '14px 16px', fontFamily: 'var(--font-mono)', fontSize: 11.5, lineHeight: 1.65, maxHeight: 300, overflowY: 'auto', color: '#a8c4e0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}
      />
      <div style={{ padding: '10px 16px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
        <button onClick={handleCopy} style={smallBtn()}>{copied ? '✓ Copied!' : '📋 Copy'}</button>
        <button onClick={() => downloadFile(content, downloadName)} style={smallBtn('success')}>⬇ Download</button>
      </div>
    </div>
  )
}

function smallBtn(v) {
  const base = { padding: '5px 12px', borderRadius: 5, fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 500, cursor: 'pointer', border: '1px solid var(--border2)', transition: 'all 0.15s' }
  if (v === 'success') return { ...base, background: 'var(--accent-green)', borderColor: 'var(--accent-green)', color: '#001a14', fontWeight: 600 }
  return { ...base, background: 'var(--surface)', color: 'var(--muted)' }
}

export default function ResultCards({ result }) {
  const udmContent = Array.isArray(result.udm_queries)
    ? result.udm_queries.map(q => `// ${q.title}\n${q.udm}`).join('\n\n')
    : result.udm_query || ''

  const jsonContent = JSON.stringify(result.secops_json, null, 2)

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 20, padding: '4px 16px', fontSize: 11, color: 'var(--text2)', fontFamily: 'var(--font-display)', fontWeight: 600, letterSpacing: '0.5px', display: 'flex', alignItems: 'center', gap: 8, whiteSpace: 'nowrap' }}>
          🤖 AI Generated Outputs
        </div>
        <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
      </div>

      <PreprocessorInsights preprocessor={result.preprocessor} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14 }}>
        <CodeCard
          title="YARA-L 2.0 Rule"
          badge="YARA-L"
          badgeColor={{ bg: 'rgba(255,107,53,0.15)', text: 'var(--accent-orange)', border: 'rgba(255,107,53,0.3)' }}
          content={result.yaral}
          type="yaral"
          downloadName="detection_rule.yaral"
        />
        <CodeCard
          title="Chronicle UDM Query"
          badge="UDM"
          badgeColor={{ bg: 'rgba(38,132,255,0.15)', text: 'var(--accent-blue)', border: 'rgba(38,132,255,0.3)' }}
          content={udmContent}
          type="udm"
          downloadName="udm_query.txt"
        />
        <CodeCard
          title="SecOps API JSON"
          badge="JSON"
          badgeColor={{ bg: 'rgba(255,209,102,0.15)', text: 'var(--accent-yellow)', border: 'rgba(255,209,102,0.3)' }}
          content={jsonContent}
          type="json"
          downloadName="secops_rule.json"
        />
      </div>
    </div>
  )
}
