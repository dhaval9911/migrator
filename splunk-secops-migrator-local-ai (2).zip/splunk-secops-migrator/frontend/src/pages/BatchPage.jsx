import { useState } from 'react'
import { batchMigrate } from '../utils/api'

const EMPTY_ITEM = () => ({ id: Date.now(), content: '', type: 'alert', name: '' })

export default function BatchPage({ onMigrated }) {
  const [items, setItems] = useState([EMPTY_ITEM()])
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const updateItem = (id, field, value) =>
    setItems(prev => prev.map(i => i.id === id ? { ...i, [field]: value } : i))

  const addItem = () => setItems(prev => [...prev, EMPTY_ITEM()])
  const removeItem = (id) => setItems(prev => prev.filter(i => i.id !== id))

  const handleBatch = async () => {
    const valid = items.filter(i => i.content.trim())
    if (!valid.length) return
    setLoading(true); setError(null); setResult(null)
    try {
      const res = await batchMigrate(valid.map(({ content, type, name }) => ({
        content, migration_type: type, name: name || undefined
      })))
      setResult(res)
      onMigrated?.()
    } catch (e) {
      setError(e.response?.data?.detail || e.message)
    } finally {
      setLoading(false)
    }
  }

  const downloadAll = () => {
    if (!result) return
    const out = JSON.stringify(result, null, 2)
    const blob = new Blob([out], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `batch_migration_${result.batch_id?.slice(0,8)}.json`; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, letterSpacing: '-0.5px' }}>
          📦 <span style={{ color: 'var(--accent-blue)' }}>Batch</span> Migration
        </h1>
        <p style={{ marginTop: 8, fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>
          Migrate up to 20 Splunk items in one shot. Mix alerts and dashboards freely.
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
        {items.map((item, idx) => (
          <div key={item.id} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 16px', background: 'var(--surface2)', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12, color: 'var(--muted)' }}>#{idx + 1}</span>
              <input
                value={item.name} onChange={e => updateItem(item.id, 'name', e.target.value)}
                placeholder="Name (optional)"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 5, padding: '5px 10px', color: 'var(--text)', fontSize: 11, fontFamily: 'var(--font-mono)', outline: 'none', width: 180 }}
              />
              <div style={{ display: 'flex', gap: 6 }}>
                {['alert', 'dashboard'].map(t => (
                  <button key={t} onClick={() => updateItem(item.id, 'type', t)} style={{
                    padding: '4px 12px', borderRadius: 5, cursor: 'pointer', fontSize: 11, fontFamily: 'var(--font-mono)',
                    border: `1px solid ${item.type === t ? (t === 'alert' ? 'var(--accent-orange)' : 'var(--accent-blue)') : 'var(--border2)'}`,
                    background: item.type === t ? (t === 'alert' ? 'rgba(255,107,53,0.1)' : 'rgba(38,132,255,0.1)') : 'transparent',
                    color: item.type === t ? (t === 'alert' ? 'var(--accent-orange)' : 'var(--accent-blue)') : 'var(--muted)',
                  }}>
                    {t === 'alert' ? '🚨 Alert' : '📊 Dashboard'}
                  </button>
                ))}
              </div>
              <button onClick={() => removeItem(item.id)} disabled={items.length === 1} style={{
                marginLeft: 'auto', padding: '4px 10px', borderRadius: 5, cursor: 'pointer', fontSize: 11,
                background: 'transparent', border: '1px solid var(--accent-orange)', color: 'var(--accent-orange)',
                opacity: items.length === 1 ? 0.3 : 1,
              }}>✕ Remove</button>
            </div>
            <textarea
              value={item.content} onChange={e => updateItem(item.id, 'content', e.target.value)}
              placeholder={`Paste Splunk ${item.type} content here...`}
              style={{ fontFamily: 'var(--font-mono)', fontSize: 12, lineHeight: 1.6, color: 'var(--text)', background: 'transparent', border: 'none', outline: 'none', resize: 'vertical', width: '100%', minHeight: 120, padding: '14px 16px' }}
              spellCheck={false}
            />
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
        <button onClick={addItem} disabled={items.length >= 20} style={{
          padding: '8px 18px', borderRadius: 7, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 12,
          background: 'transparent', border: '1px dashed var(--border2)', color: 'var(--text2)', opacity: items.length >= 20 ? 0.4 : 1,
        }}>+ Add Item ({items.length}/20)</button>
        <button onClick={handleBatch} disabled={loading || !items.some(i => i.content.trim())} style={{
          padding: '8px 22px', borderRadius: 7, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600,
          background: 'var(--accent-blue)', border: '1px solid var(--accent-blue)', color: 'white',
          opacity: (loading || !items.some(i => i.content.trim())) ? 0.4 : 1,
        }}>{loading ? '⏳ Processing...' : `⚡ Run Batch (${items.filter(i=>i.content.trim()).length} items)`}</button>
      </div>

      {error && (
        <div style={{ padding: '14px 18px', background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.25)', borderRadius: 8, color: 'var(--accent-orange)', fontSize: 12, marginBottom: 16 }}>
          <strong>Batch Error</strong><br />{error}
        </div>
      )}

      {result && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', gap: 20, fontSize: 13 }}>
              <span style={{ color: 'var(--text2)' }}>Batch <span style={{ color: 'var(--text)', fontWeight: 600 }}>{result.batch_id?.slice(0,8)}</span></span>
              <span style={{ color: 'var(--accent-green)' }}>✓ {result.succeeded} succeeded</span>
              {result.failed > 0 && <span style={{ color: 'var(--accent-orange)' }}>✕ {result.failed} failed</span>}
            </div>
            <button onClick={downloadAll} style={{
              padding: '6px 16px', borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600,
              background: 'var(--accent-green)', border: '1px solid var(--accent-green)', color: '#001a14',
            }}>⬇ Export All JSON</button>
          </div>

          <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {result.results?.map((r, i) => (
              <div key={i} style={{ background: 'var(--surface2)', border: `1px solid ${r.status === 'success' ? 'rgba(0,200,150,0.2)' : 'rgba(255,107,53,0.2)'}`, borderRadius: 8, padding: '12px 16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: r.status === 'success' ? 8 : 0 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: r.status === 'success' ? 'var(--accent-green)' : 'var(--accent-orange)' }}>
                    {r.status === 'success' ? '✓' : '✕'} Item {i + 1}
                  </span>
                  {r.data?.analysis?.severity && (
                    <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 4, background: 'rgba(255,107,53,0.1)', color: 'var(--accent-orange)', border: '1px solid rgba(255,107,53,0.2)', fontWeight: 700 }}>
                      {r.data.analysis.severity.toUpperCase()}
                    </span>
                  )}
                  {r.status === 'failed' && <span style={{ fontSize: 12, color: 'var(--muted)' }}>{r.error}</span>}
                </div>
                {r.status === 'success' && r.data?.analysis?.detection_logic && (
                  <div style={{ fontSize: 12, color: 'var(--text2)', lineHeight: 1.5 }}>{r.data.analysis.detection_logic}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
