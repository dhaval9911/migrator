import { useState, useEffect } from 'react'
import { getHistory, getMigration, deleteMigration, exportAll } from '../utils/api'

const SEV_COLORS = {
  critical: { bg: 'rgba(255,77,109,0.12)', text: '#ff4d6d', border: 'rgba(255,77,109,0.25)' },
  high: { bg: 'rgba(255,107,53,0.12)', text: 'var(--accent-orange)', border: 'rgba(255,107,53,0.25)' },
  medium: { bg: 'rgba(255,209,102,0.12)', text: 'var(--accent-yellow)', border: 'rgba(255,209,102,0.25)' },
  low: { bg: 'rgba(0,200,150,0.12)', text: 'var(--accent-green)', border: 'rgba(0,200,150,0.25)' },
}

export default function HistoryPage() {
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [detail, setDetail] = useState(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [filterType, setFilterType] = useState('')
  const [page, setPage] = useState(0)
  const limit = 20

  const fetchHistory = async () => {
    setLoading(true)
    try {
      const data = await getHistory({ limit, offset: page * limit, migration_type: filterType || undefined })
      setItems(data.items)
      setTotal(data.total)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchHistory() }, [page, filterType])

  const openDetail = async (id) => {
    setSelected(id); setDetailLoading(true)
    try {
      const d = await getMigration(id)
      setDetail(d)
    } catch (e) { console.error(e) }
    finally { setDetailLoading(false) }
  }

  const handleDelete = async (id) => {
    if (!confirm('Delete this migration?')) return
    await deleteMigration(id)
    if (selected === id) { setSelected(null); setDetail(null) }
    fetchHistory()
  }

  const handleExportAll = async () => {
    const data = await exportAll()
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'all_migrations.json'; a.click()
    URL.revokeObjectURL(url)
  }

  const sev = (s) => SEV_COLORS[s?.toLowerCase()] || { bg: 'var(--surface2)', text: 'var(--muted)', border: 'var(--border)' }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, letterSpacing: '-0.5px' }}>
            📋 Migration <span style={{ color: 'var(--accent-blue)' }}>History</span>
          </h1>
          <p style={{ marginTop: 6, fontSize: 13, color: 'var(--text2)' }}>{total} migrations stored in local database</p>
        </div>
        <button onClick={handleExportAll} style={{
          padding: '8px 20px', borderRadius: 7, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600,
          background: 'var(--accent-green)', border: '1px solid var(--accent-green)', color: '#001a14',
        }}>⬇ Export All</button>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['', 'alert', 'dashboard'].map(f => (
          <button key={f} onClick={() => { setFilterType(f); setPage(0) }} style={{
            padding: '6px 16px', borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11,
            border: `1px solid ${filterType === f ? 'var(--accent-blue)' : 'var(--border2)'}`,
            background: filterType === f ? 'rgba(38,132,255,0.1)' : 'transparent',
            color: filterType === f ? 'var(--accent-blue)' : 'var(--muted)',
          }}>
            {f === '' ? 'All' : f === 'alert' ? '🚨 Alerts' : '📊 Dashboards'}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 1fr' : '1fr', gap: 16 }}>
        {/* List */}
        <div>
          {loading ? (
            <div style={{ textAlign: 'center', padding: 40, color: 'var(--muted)' }}>Loading...</div>
          ) : items.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)', border: '1px dashed var(--border)', borderRadius: 10, fontSize: 13 }}>
              No migrations yet. Go to ⚡ Migrate to get started.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {items.map(item => (
                <div
                  key={item.id}
                  onClick={() => openDetail(item.id)}
                  style={{
                    background: selected === item.id ? 'var(--surface2)' : 'var(--surface)',
                    border: `1px solid ${selected === item.id ? 'var(--accent-blue)' : 'var(--border)'}`,
                    borderRadius: 8, padding: '12px 16px', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 12, transition: 'all 0.15s',
                  }}
                >
                  <span style={{ fontSize: 16 }}>{item.migration_type === 'alert' ? '🚨' : '📊'}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {item.name || 'Unnamed Migration'}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {item.snippet}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
                    {item.severity && (
                      <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, fontWeight: 700, ...sev(item.severity) }}>
                        {item.severity.toUpperCase()}
                      </span>
                    )}
                    <span style={{ fontSize: 10, color: 'var(--accent-green)' }}>✓</span>
                    <span style={{ fontSize: 10, color: 'var(--muted)' }}>{new Date(item.created_at).toLocaleString()}</span>
                    <button
                      onClick={e => { e.stopPropagation(); handleDelete(item.id) }}
                      style={{ padding: '3px 8px', borderRadius: 4, cursor: 'pointer', fontSize: 11, background: 'transparent', border: '1px solid var(--border)', color: 'var(--muted)' }}
                    >✕</button>
                  </div>
                </div>
              ))}

              {/* Pagination */}
              {total > limit && (
                <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 8 }}>
                  <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} style={{ padding: '5px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 11, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text2)', opacity: page === 0 ? 0.3 : 1 }}>← Prev</button>
                  <span style={{ fontSize: 11, color: 'var(--muted)', alignSelf: 'center' }}>Page {page + 1} of {Math.ceil(total / limit)}</span>
                  <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * limit >= total} style={{ padding: '5px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 11, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text2)', opacity: (page + 1) * limit >= total ? 0.3 : 1 }}>Next →</button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Detail pane */}
        {selected && (
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden', position: 'sticky', top: 80, maxHeight: 'calc(100vh - 100px)', overflowY: 'auto' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 18px', background: 'var(--surface2)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 10 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '1.2px', textTransform: 'uppercase', color: 'var(--text2)' }}>DETAIL VIEW</span>
              <button onClick={() => { setSelected(null); setDetail(null) }} style={{ padding: '4px 10px', borderRadius: 5, cursor: 'pointer', fontSize: 11, background: 'transparent', border: '1px solid var(--border)', color: 'var(--muted)' }}>✕ Close</button>
            </div>

            {detailLoading ? (
              <div style={{ padding: 40, textAlign: 'center', color: 'var(--muted)' }}>Loading...</div>
            ) : detail ? (
              <div style={{ padding: 16 }}>
                {/* YARA-L */}
                {detail.yaral && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 10, color: 'var(--accent-orange)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>YARA-L 2.0</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.6, color: '#a8c4e0', background: 'var(--surface2)', padding: '12px 14px', borderRadius: 7, border: '1px solid var(--border)', whiteSpace: 'pre-wrap', maxHeight: 200, overflowY: 'auto' }}>
                      {detail.yaral}
                    </div>
                  </div>
                )}
                {/* UDM */}
                {detail.udm_query && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 10, color: 'var(--accent-blue)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>UDM Query</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.6, color: '#a8c4e0', background: 'var(--surface2)', padding: '12px 14px', borderRadius: 7, border: '1px solid var(--border)', whiteSpace: 'pre-wrap', maxHeight: 150, overflowY: 'auto' }}>
                      {detail.udm_query}
                    </div>
                  </div>
                )}
                {/* Notes */}
                {detail.migration_notes?.length > 0 && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 10, color: 'var(--accent-yellow)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>Migration Notes</div>
                    {detail.migration_notes.map((n, i) => (
                      <div key={i} style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 5, display: 'flex', gap: 6, lineHeight: 1.5 }}>
                        <span style={{ color: 'var(--accent-yellow)', flexShrink: 0 }}>⚠</span>{n}
                      </div>
                    ))}
                  </div>
                )}
                {/* JSON */}
                {detail.secops_json && (
                  <div>
                    <div style={{ fontSize: 10, color: 'var(--accent-yellow)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>SecOps JSON</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.6, color: '#a8c4e0', background: 'var(--surface2)', padding: '12px 14px', borderRadius: 7, border: '1px solid var(--border)', whiteSpace: 'pre-wrap', maxHeight: 200, overflowY: 'auto' }}>
                      {JSON.stringify(detail.secops_json, null, 2)}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  )
}
