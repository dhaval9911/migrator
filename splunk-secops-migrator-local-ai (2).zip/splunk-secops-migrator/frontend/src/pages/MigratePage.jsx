import { useState, useRef, useCallback } from 'react'
import { migrateContent, migrateFile } from '../utils/api'
import ResultCards from '../components/ResultCards'

const SAMPLE_ALERT = `[alert_brute_force_ssh]
search = index=linux_logs sourcetype=sshd "Failed password" | stats count by src_ip, user | where count > 10 | eval severity="high"
dispatch.earliest_time = -15m
dispatch.latest_time = now
alert.threshold = 1
alert.condition = search count > 0
cron_schedule = */15 * * * *
description = Detects brute force SSH login attempts from a single source IP`

const SAMPLE_DASHBOARD = `<dashboard>
  <label>Security Operations Center</label>
  <row>
    <panel>
      <title>Failed Logins by Source IP (Last 24h)</title>
      <chart>
        <search>
          <query>index=security sourcetype=WinEventLog:Security EventCode=4625 | stats count by src_ip | sort -count | head 20</query>
          <earliest>-24h@h</earliest>
        </search>
        <option name="charting.chart">bar</option>
      </chart>
    </panel>
    <panel>
      <title>Malware Detections</title>
      <table>
        <search>
          <query>index=endpoint sourcetype=symantec action=blocked | table _time, host, file_path, threat_name | sort -_time</query>
          <earliest>-7d@d</earliest>
        </search>
      </table>
    </panel>
  </row>
  <row>
    <panel>
      <title>Network Connections to Threat Intel IPs</title>
      <table>
        <search>
          <query>index=network sourcetype=firewall action=blocked | lookup threat_intel src_ip OUTPUT threat_category | where isnotnull(threat_category) | table _time, src_ip, dest_ip, threat_category</query>
        </search>
      </table>
    </panel>
  </row>
</dashboard>`

const LOADING_STEPS = [
  'Parsing Splunk content...',
  'Analyzing SPL logic...',
  'Generating YARA-L 2.0 rule...',
  'Building UDM queries...',
  'Constructing SecOps JSON...',
  'Finalizing migration...',
]

export default function MigratePage({ onMigrated }) {
  const [type, setType] = useState('alert')
  const [input, setInput] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [loadStep, setLoadStep] = useState(0)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef()

  const handleMigrate = async () => {
    if (!input.trim()) return
    setLoading(true); setError(null); setResult(null); setLoadStep(0)

    const interval = setInterval(() => setLoadStep(s => Math.min(s + 1, LOADING_STEPS.length - 1)), 700)
    try {
      const res = await migrateContent(input, type, name || undefined)
      clearInterval(interval)
      setResult(res)
      onMigrated?.()
    } catch (e) {
      clearInterval(interval)
      setError(e.response?.data?.detail || e.message)
    } finally {
      setLoading(false)
    }
  }

  const handleFile = async (file) => {
    if (!file) return
    setLoading(true); setError(null); setResult(null); setLoadStep(0)
    const interval = setInterval(() => setLoadStep(s => Math.min(s + 1, LOADING_STEPS.length - 1)), 700)
    try {
      const res = await migrateFile(file, type, name || file.name)
      clearInterval(interval)
      setResult(res)
      onMigrated?.()
    } catch (e) {
      clearInterval(interval)
      setError(e.response?.data?.detail || e.message)
    } finally {
      setLoading(false)
    }
  }

  const onDrop = useCallback((e) => {
    e.preventDefault(); setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [type, name])

  return (
    <div>
      {/* Hero */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 800, letterSpacing: '-1px', lineHeight: 1.15 }}>
          <span style={{ color: 'var(--accent-blue)' }}>AI-Powered</span> Migration<br />
          <span style={{ color: 'var(--splunk)' }}>Splunk</span> <span style={{ color: 'var(--muted)' }}>→</span> <span style={{ color: 'var(--secops)' }}>Google SecOps</span>
        </h1>
        <p style={{ marginTop: 10, fontSize: 13, color: 'var(--text2)', lineHeight: 1.6, maxWidth: 560 }}>
          Paste SPL alerts, .conf files, or dashboard XML — Claude converts them to YARA-L 2.0 rules, Chronicle UDM queries, and SecOps API JSON.
        </p>
      </div>

      {/* Controls bar */}
      <div style={{
        background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10,
        padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16, flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', gap: 6 }}>
          {['alert', 'dashboard'].map(t => (
            <button key={t} onClick={() => setType(t)} style={{
              padding: '7px 16px', borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 500,
              border: `1px solid ${type === t ? (t === 'alert' ? 'var(--accent-orange)' : 'var(--accent-blue)') : 'var(--border2)'}`,
              background: type === t ? (t === 'alert' ? 'rgba(255,107,53,0.1)' : 'rgba(38,132,255,0.1)') : 'transparent',
              color: type === t ? (t === 'alert' ? 'var(--accent-orange)' : 'var(--accent-blue)') : 'var(--muted)',
              transition: 'all 0.15s',
            }}>
              {t === 'alert' ? '🚨 Alert / .conf' : '📊 Dashboard XML'}
            </button>
          ))}
        </div>

        <input
          value={name} onChange={e => setName(e.target.value)} placeholder="Name (optional)"
          style={{
            background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 6,
            padding: '7px 12px', color: 'var(--text)', fontSize: 12, fontFamily: 'var(--font-mono)',
            outline: 'none', width: 200,
          }}
        />

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          <button onClick={() => setInput(type === 'alert' ? SAMPLE_ALERT : SAMPLE_DASHBOARD)} style={btnStyle()}>
            Load Sample
          </button>
          <button onClick={() => fileRef.current?.click()} style={btnStyle()}>📁 Upload</button>
          <input ref={fileRef} type="file" accept=".xml,.conf,.spl,.txt" style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
          <button onClick={handleMigrate} disabled={loading || !input.trim()} style={btnStyle('primary')}>
            {loading ? 'Migrating...' : '⚡ Migrate →'}
          </button>
        </div>
      </div>

      {/* Workspace */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Input */}
        <div style={panelStyle()}>
          <div style={panelHeaderStyle()}>
            <span style={panelTitleStyle()}><span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: 'var(--splunk)', marginRight: 8 }} />SPLUNK INPUT</span>
            <button onClick={() => { setInput(''); setResult(null); setError(null) }} style={btnStyle('danger')}>Clear</button>
          </div>
          <textarea
            value={input} onChange={e => setInput(e.target.value)}
            placeholder={`Paste your Splunk ${type === 'alert' ? 'alert / saved search (.conf)' : 'dashboard XML'} here...\n\nOr drag & drop a file below.`}
            style={{
              fontFamily: 'var(--font-mono)', fontSize: 12.5, lineHeight: 1.7, color: 'var(--text)',
              background: 'transparent', border: 'none', outline: 'none', resize: 'none',
              width: '100%', minHeight: 300, padding: '16px 18px',
            }}
            spellCheck={false}
          />
          <div
            onDragOver={e => { e.preventDefault(); setDragging(true) }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            onClick={() => fileRef.current?.click()}
            style={{
              margin: '0 14px 14px', padding: '16px',
              border: `2px dashed ${dragging ? 'var(--accent-blue)' : 'var(--border2)'}`,
              borderRadius: 8, textAlign: 'center', cursor: 'pointer',
              color: dragging ? 'var(--accent-blue)' : 'var(--muted)',
              fontSize: 12, transition: 'all 0.2s',
              background: dragging ? 'rgba(38,132,255,0.04)' : 'transparent',
            }}
          >
            📂 Drop .xml or .conf file here
          </div>
        </div>

        {/* Output preview */}
        <div style={panelStyle()}>
          <div style={panelHeaderStyle()}>
            <span style={panelTitleStyle()}><span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: 'var(--secops)', marginRight: 8 }} />MIGRATION PREVIEW</span>
            {result && <span style={{ fontSize: 11, color: 'var(--accent-green)' }}>✓ Success</span>}
          </div>

          {!result && !loading && !error && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 300, gap: 10, color: 'var(--muted)' }}>
              <div style={{ fontSize: 36, opacity: 0.25 }}>🛡️</div>
              <div style={{ fontSize: 12, textAlign: 'center', lineHeight: 1.7 }}>
                Paste Splunk content and click<br />
                <strong style={{ color: 'var(--accent-blue)' }}>⚡ Migrate →</strong><br />
                to generate SecOps outputs
              </div>
            </div>
          )}

          {loading && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 300, gap: 16 }}>
              <div style={{ width: 38, height: 38, border: '2px solid var(--border2)', borderTopColor: 'var(--accent-blue)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
              <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
              <div style={{ fontSize: 11, textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 4 }}>
                {LOADING_STEPS.map((s, i) => (
                  <div key={i} style={{ color: i === loadStep ? 'var(--accent-blue)' : i < loadStep ? 'var(--accent-green)' : 'var(--muted)' }}>
                    {i < loadStep ? '✓' : i === loadStep ? '→' : '·'} {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && (
            <div style={{ margin: 16, padding: '14px 18px', background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.25)', borderRadius: 8, color: 'var(--accent-orange)', fontSize: 12 }}>
              <strong>Migration Error</strong><br />{error}
            </div>
          )}

          {result && !loading && (
            <div style={{ padding: 18 }}>
              {result.analysis?.detection_logic && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '1.2px', textTransform: 'uppercase', fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 8 }}>Detection Logic</div>
                  <div style={{ fontSize: 12, color: 'var(--text)', lineHeight: 1.7, background: 'var(--surface2)', padding: '10px 14px', borderRadius: 6, border: '1px solid var(--border)' }}>
                    {result.analysis.detection_logic}
                  </div>
                </div>
              )}
              {result.analysis?.title && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '1.2px', textTransform: 'uppercase', fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 8 }}>Dashboard</div>
                  <div style={{ fontSize: 12, color: 'var(--text)', lineHeight: 1.7, background: 'var(--surface2)', padding: '10px 14px', borderRadius: 6, border: '1px solid var(--border)' }}>
                    {result.analysis.title} — {result.analysis.panel_count} panels
                  </div>
                </div>
              )}
              {result.analysis?.data_sources?.length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '1.2px', textTransform: 'uppercase', fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 8 }}>Data Sources</div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {result.analysis.data_sources.map((ds, i) => (
                      <span key={i} style={{ fontSize: 11, padding: '3px 10px', borderRadius: 4, background: 'rgba(38,132,255,0.1)', border: '1px solid rgba(38,132,255,0.2)', color: 'var(--accent-blue)' }}>{ds}</span>
                    ))}
                  </div>
                </div>
              )}
              {result.migration_notes?.length > 0 && (
                <div>
                  <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '1.2px', textTransform: 'uppercase', fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 8 }}>Migration Notes</div>
                  {result.migration_notes.map((n, i) => (
                    <div key={i} style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 6, display: 'flex', gap: 8, lineHeight: 1.5 }}>
                      <span style={{ color: 'var(--accent-yellow)', flexShrink: 0 }}>⚠</span> {n}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Result cards */}
      {result && !loading && <ResultCards result={result} />}
    </div>
  )
}

function panelStyle() {
  return { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden' }
}

function panelHeaderStyle() {
  return { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 18px', borderBottom: '1px solid var(--border)', background: 'var(--surface2)' }
}

function panelTitleStyle() {
  return { fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '1.5px', textTransform: 'uppercase', color: 'var(--text2)', display: 'flex', alignItems: 'center' }
}

function btnStyle(variant) {
  const base = { padding: '7px 14px', borderRadius: 6, fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 500, cursor: 'pointer', border: '1px solid var(--border2)', transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: 5 }
  if (variant === 'primary') return { ...base, background: 'var(--accent-blue)', borderColor: 'var(--accent-blue)', color: 'white', fontWeight: 600 }
  if (variant === 'danger') return { ...base, background: 'transparent', borderColor: 'var(--accent-orange)', color: 'var(--accent-orange)' }
  if (variant === 'success') return { ...base, background: 'var(--accent-green)', borderColor: 'var(--accent-green)', color: '#001a14', fontWeight: 600 }
  return { ...base, background: 'var(--surface)', color: 'var(--muted)' }
}

export { btnStyle, panelStyle, panelHeaderStyle, panelTitleStyle }
