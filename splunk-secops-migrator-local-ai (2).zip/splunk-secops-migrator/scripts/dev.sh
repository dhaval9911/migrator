#!/bin/bash

# ─────────────────────────────────────────────
#  Dev mode: backend + frontend with hot reload
# ─────────────────────────────────────────────

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"

cleanup() {
  echo ""
  echo "Stopping servers..."
  kill $BACKEND_PID $FRONTEND_PID 2>/dev/null
  exit 0
}
trap cleanup INT TERM

echo ""
echo -e "${BLUE}${BOLD}  Starting Dev Mode (hot reload)${NC}"
echo ""

# Backend
cd "$BACKEND_DIR"
source venv/bin/activate
python3 -c "from app.core.database import init_db; init_db()" 2>/dev/null
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!
echo -e "${GREEN}  ✓ Backend: http://localhost:8000${NC}"

sleep 2

# Frontend dev server
cd "$FRONTEND_DIR"
npm run dev &
FRONTEND_PID=$!
echo -e "${GREEN}  ✓ Frontend: http://localhost:5173${NC}"

echo ""
echo -e "  ${BOLD}API Docs:${NC} http://localhost:8000/docs"
echo -e "  Press ${BOLD}Ctrl+C${NC} to stop both servers"
echo ""

wait
