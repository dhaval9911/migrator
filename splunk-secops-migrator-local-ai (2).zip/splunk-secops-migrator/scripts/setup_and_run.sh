#!/bin/bash
set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"

clear
echo ""
echo -e "${BLUE}${BOLD}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}${BOLD}║   Splunk → Google SecOps AI Migrator              ║${NC}"
echo -e "${BLUE}${BOLD}║   100% Local • No API Key • Free Forever           ║${NC}"
echo -e "${BLUE}${BOLD}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# ── RAM check ───────────────────────────────────────
TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_RAM_GB=$((TOTAL_RAM_KB / 1024 / 1024))
echo -e "  💾 Detected RAM: ${BOLD}${TOTAL_RAM_GB} GB${NC}"
if [ "$TOTAL_RAM_GB" -lt 4 ]; then
  echo -e "  ${YELLOW}⚠  Less than 4 GB RAM detected. Recommend phi3 model.${NC}"
  DEFAULT_MODEL="phi3"
elif [ "$TOTAL_RAM_GB" -lt 8 ]; then
  echo -e "  ${CYAN}ℹ  4-8 GB RAM: llama3.2 (2 GB) recommended.${NC}"
  DEFAULT_MODEL="llama3.2"
else
  echo -e "  ${GREEN}✓  8+ GB RAM: mistral recommended (best quality).${NC}"
  DEFAULT_MODEL="mistral"
fi
echo ""

# ── .env setup ──────────────────────────────────────
if [ ! -f "$BACKEND_DIR/.env" ]; then
  cp "$BACKEND_DIR/.env.example" "$BACKEND_DIR/.env"
  sed -i "s/^OLLAMA_MODEL=mistral/OLLAMA_MODEL=$DEFAULT_MODEL/" "$BACKEND_DIR/.env"
fi

# ── [1] Install system packages ─────────────────────
echo -e "${BOLD}[1/5] System packages...${NC}"
sudo apt-get update -qq
sudo apt-get install -y -qq python3 python3-pip python3-venv curl
echo -e "${GREEN}   ✓ Done${NC}"

# ── [2] Install Ollama ──────────────────────────────
echo -e "${BOLD}[2/5] Ollama (local AI engine)...${NC}"
if command -v ollama &>/dev/null; then
  echo -e "${GREEN}   ✓ Ollama already installed: $(ollama --version)${NC}"
else
  echo -e "   Installing Ollama..."
  curl -fsSL https://ollama.com/install.sh | sh
  echo -e "${GREEN}   ✓ Ollama installed${NC}"
fi

# Start ollama service if not running
if ! pgrep -x "ollama" > /dev/null; then
  echo -e "   Starting Ollama server..."
  ollama serve &>/dev/null &
  sleep 3
fi

# ── [3] Pull LLM model ──────────────────────────────
CHOSEN_MODEL=$(grep "^OLLAMA_MODEL=" "$BACKEND_DIR/.env" | cut -d= -f2 | tr -d ' ')
echo -e "${BOLD}[3/5] Pulling model: ${CYAN}$CHOSEN_MODEL${NC}${BOLD}...${NC}"
echo -e "   ${YELLOW}(This downloads the model file — only needed once)${NC}"

MODEL_SIZES=( "phi3:2.3GB" "llama3.2:2.0GB" "mistral:4.1GB" "llama3.1:4.7GB" "gemma2:5.4GB" )
for ms in "${MODEL_SIZES[@]}"; do
  if [[ "$ms" == "$CHOSEN_MODEL:"* ]]; then
    SIZE="${ms#*:}"
    echo -e "   📦 Downloading ~$SIZE to ~/.ollama/models/ ..."
    break
  fi
done

ollama pull "$CHOSEN_MODEL"
echo -e "${GREEN}   ✓ Model $CHOSEN_MODEL ready${NC}"

# ── [4] Python backend ──────────────────────────────
echo -e "${BOLD}[4/5] Python backend...${NC}"
cd "$BACKEND_DIR"
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
python3 -c "from app.core.database import init_db; init_db()"
echo -e "${GREEN}   ✓ Backend ready${NC}"

# ── [5] Frontend ────────────────────────────────────
echo -e "${BOLD}[5/5] Frontend...${NC}"
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - >/dev/null 2>&1
  sudo apt-get install -y -qq nodejs
fi
cd "$FRONTEND_DIR"
if [ ! -d "node_modules" ]; then
  npm install --silent
fi
npm run build --silent
echo -e "${GREEN}   ✓ Frontend built${NC}"

# ── Launch ──────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║   ✓ Setup complete! Launching...                  ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🌐 App:      ${BOLD}http://localhost:8000${NC}"
echo -e "  📖 API Docs: ${BOLD}http://localhost:8000/docs${NC}"
echo -e "  🤖 Model:    ${BOLD}$CHOSEN_MODEL${NC} (running locally on your CPU)"
echo ""
echo -e "  Press ${BOLD}Ctrl+C${NC} to stop"
echo ""

cd "$BACKEND_DIR"
source venv/bin/activate
python3 run.py
