import uvicorn
from app.main import app
from app.core.database import init_db

if __name__ == "__main__":
    init_db()
    print("\n🚀 Splunk → SecOps Migrator API starting...")
    print("📖 Swagger docs: http://localhost:8000/docs")
    print("📋 ReDoc:        http://localhost:8000/redoc\n")
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
