"""
AI Migration Service
--------------------
Orchestrates: pre-processing → few-shot LLM prompt → output validation → retry.
The LLM is guided by pre-analyzed context so it doesn't need to "know" Splunk —
the preprocessor injects the expertise deterministically.
"""

import httpx
import json
import re
from datetime import datetime
from typing import Dict, Any, Optional

from app.core.config import settings
from app.services.preprocessor import (
    parse_alert, parse_dashboard,
    build_alert_context, build_dashboard_context,
    SPL_TO_UDM,
)

# ─────────────────────────────────────────────────────────────────────────────
#  System prompt — model persona
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are a Google SecOps (Chronicle) migration engineer.
You receive pre-analyzed Splunk content with field mappings already resolved.
Use the provided UDM field mappings exactly — do not invent field names.
Respond ONLY with a valid JSON object. No markdown, no explanation.
The JSON must start with { and end with }.
"""

# ─────────────────────────────────────────────────────────────────────────────
#  Few-shot examples — these teach the model the output format and patterns
# ─────────────────────────────────────────────────────────────────────────────

FEW_SHOT_ALERT = """\
=== EXAMPLE 1: Brute Force SSH ===

INPUT CONTEXT:
NAME: alert_brute_force_ssh
SPL QUERY: index=linux_logs sourcetype=sshd "Failed password" | stats count by src_ip | where count > 10
SEVERITY: HIGH
TIME WINDOW: 15 minutes
THRESHOLD: count > 10
TYPE: Aggregation/count-based detection → use YARA-L match..over..condition with #e
FIELD MAPPINGS:
  src_ip → principal.ip
UDM LOG TYPE: SYSLOG
SPL COMMAND TRANSLATIONS:
  • SPL `stats count by` → group_by + count()
  • SPL `where count >` → YARA-L condition: #e > N

OUTPUT:
{
  "analysis": {
    "type": "alert",
    "splunk_search": "index=linux_logs sourcetype=sshd \\"Failed password\\" | stats count by src_ip | where count > 10",
    "detection_logic": "Detects SSH brute force by counting failed login attempts from a single IP over 15 minutes. Triggers when count exceeds 10.",
    "severity": "high",
    "data_sources": ["SYSLOG", "linux_logs"]
  },
  "yaral": "rule brute_force_ssh {\\n  meta:\\n    description = \\"Detects SSH brute force login attempts\\"\\n    severity = \\"HIGH\\"\\n    author = \\"splunk-migrator\\"\\n  events:\\n    $e.metadata.log_type = \\"SYSLOG\\"\\n    $e.security_result.action = \\"BLOCK\\"\\n    re.regex($e.metadata.description, `Failed password`)\\n    $e.principal.ip = $src_ip\\n  match:\\n    $src_ip over 15m\\n  condition:\\n    #e > 10\\n}",
  "udm_query": "metadata.log_type = \\"SYSLOG\\" AND security_result.action = \\"BLOCK\\" AND metadata.description = /Failed password/",
  "secops_json": {
    "name": "brute_force_ssh",
    "displayName": "SSH Brute Force Detection",
    "description": "Detects SSH brute force login attempts — >10 failures from single IP in 15 minutes",
    "severity": "HIGH",
    "type": "MULTI_EVENT",
    "enabled": true,
    "metadata": {"author": "splunk-migrator", "category": "credential-access", "mitre": "T1110"}
  },
  "migration_notes": [
    "src_ip mapped to principal.ip",
    "stats count by → YARA-L match $src_ip over 15m with condition #e > 10",
    "index=linux_logs mapped to UDM log_type SYSLOG",
    "Sourcetype sshd encoded as metadata.log_type filter"
  ]
}

=== EXAMPLE 2: Windows Failed Logon ===

INPUT CONTEXT:
NAME: alert_failed_logon
SPL QUERY: index=security sourcetype=WinEventLog:Security EventCode=4625 | stats count by src_ip, user | where count >= 5
SEVERITY: HIGH
TIME WINDOW: 10 minutes
THRESHOLD: count >= 5
FIELD MAPPINGS:
  src_ip → principal.ip
  user → principal.user.userid
  EventCode → metadata.product_event_type
UDM LOG TYPE: WINEVTLOG

OUTPUT:
{
  "analysis": {
    "type": "alert",
    "splunk_search": "index=security sourcetype=WinEventLog:Security EventCode=4625 | stats count by src_ip, user | where count >= 5",
    "detection_logic": "Detects Windows brute force by counting EventCode 4625 (failed logon) per source IP and username pair. Triggers at 5+ failures in 10 minutes.",
    "severity": "high",
    "data_sources": ["WINEVTLOG", "Windows Security"]
  },
  "yaral": "rule windows_failed_logon_brute_force {\\n  meta:\\n    description = \\"Multiple Windows failed logon attempts (Event 4625)\\"\\n    severity = \\"HIGH\\"\\n    mitre_attack = \\"T1110\\"\\n  events:\\n    $e.metadata.log_type = \\"WINEVTLOG\\"\\n    $e.metadata.product_event_type = \\"4625\\"\\n    $e.principal.ip = $src_ip\\n    $e.principal.user.userid = $user\\n  match:\\n    $src_ip, $user over 10m\\n  condition:\\n    #e >= 5\\n}",
  "udm_query": "metadata.log_type = \\"WINEVTLOG\\" AND metadata.product_event_type = \\"4625\\"",
  "secops_json": {
    "name": "windows_failed_logon_brute_force",
    "displayName": "Windows Failed Logon Brute Force",
    "description": "Detects multiple Windows failed logon attempts (EventCode 4625)",
    "severity": "HIGH",
    "type": "MULTI_EVENT",
    "enabled": true,
    "metadata": {"author": "splunk-migrator", "category": "credential-access", "mitre": "T1110"}
  },
  "migration_notes": [
    "EventCode 4625 mapped to metadata.product_event_type",
    "src_ip → principal.ip, user → principal.user.userid",
    "Grouped match on both $src_ip and $user over 10m window",
    "WINEVTLOG ingestion required in Chronicle"
  ]
}

=== EXAMPLE 3: Single-event malware detection ===

INPUT CONTEXT:
NAME: alert_malware_blocked
SPL QUERY: index=endpoint sourcetype=symantec action=blocked threat_name=* | table _time, host, file_path, threat_name
SEVERITY: CRITICAL
FIELD MAPPINGS:
  action → security_result.action
  threat_name → security_result.threat_name
  file_path → target.file.full_path
  host → principal.hostname
UDM LOG TYPE: EDR

OUTPUT:
{
  "analysis": {
    "type": "alert",
    "splunk_search": "index=endpoint sourcetype=symantec action=blocked threat_name=* | table _time, host, file_path, threat_name",
    "detection_logic": "Fires on any blocked malware detection from endpoint security. Single-event rule — no aggregation needed.",
    "severity": "critical",
    "data_sources": ["EDR", "endpoint"]
  },
  "yaral": "rule malware_blocked_endpoint {\\n  meta:\\n    description = \\"Detects blocked malware from endpoint security agent\\"\\n    severity = \\"CRITICAL\\"\\n    mitre_attack = \\"T1204\\"\\n  events:\\n    $e.metadata.log_type = \\"EDR\\"\\n    $e.security_result.action = \\"BLOCK\\"\\n    $e.security_result.threat_name != \\"\\"\\n    $e.principal.hostname = $host\\n  condition:\\n    $e\\n}",
  "udm_query": "metadata.log_type = \\"EDR\\" AND security_result.action = \\"BLOCK\\" AND security_result.threat_name != \\"\\"",
  "secops_json": {
    "name": "malware_blocked_endpoint",
    "displayName": "Endpoint Malware Blocked",
    "description": "Any malware block event from endpoint security (Symantec/EDR)",
    "severity": "CRITICAL",
    "type": "SINGLE_EVENT",
    "enabled": true,
    "metadata": {"author": "splunk-migrator", "category": "malware", "mitre": "T1204"}
  },
  "migration_notes": [
    "action=blocked → security_result.action = BLOCK",
    "threat_name mapped to security_result.threat_name",
    "Single-event rule — no match..over needed",
    "host → principal.hostname, file_path → target.file.full_path"
  ]
}
"""

FEW_SHOT_DASHBOARD = """\
=== EXAMPLE: SOC Dashboard with 2 panels ===

INPUT CONTEXT:
DASHBOARD: Security Operations Center
PANEL COUNT: 2

PANEL 1: Failed Logins by IP
  VIZ TYPE: chart
  SPL: index=security EventCode=4625 | stats count by src_ip | sort -count | head 20
  UDM FIELD MAPPINGS:
    src_ip → principal.ip
    EventCode → metadata.product_event_type
  • SPL `stats count by` → group_by + count()

PANEL 2: Malware Detections
  VIZ TYPE: table
  SPL: index=endpoint sourcetype=symantec action=blocked | table _time, host, file_path, threat_name | sort -_time
  UDM FIELD MAPPINGS:
    action → security_result.action
    host → principal.hostname
    file_path → target.file.full_path
    threat_name → security_result.threat_name

OUTPUT:
{
  "analysis": {
    "type": "dashboard",
    "title": "Security Operations Center",
    "panel_count": 2,
    "panels": [
      {"title": "Failed Logins by IP", "spl": "index=security EventCode=4625 | stats count by src_ip | sort -count | head 20", "viz_type": "chart"},
      {"title": "Malware Detections", "spl": "index=endpoint sourcetype=symantec action=blocked | table _time, host, file_path, threat_name | sort -_time", "viz_type": "table"}
    ]
  },
  "yaral": "rule soc_failed_logins {\\n  meta:\\n    description = \\"SOC dashboard: failed login pattern\\"\\n    severity = \\"MEDIUM\\"\\n  events:\\n    $e.metadata.product_event_type = \\"4625\\"\\n    $e.principal.ip = $ip\\n  match:\\n    $ip over 1h\\n  condition:\\n    #e > 5\\n}",
  "udm_query": "metadata.product_event_type = \\"4625\\"",
  "udm_queries": [
    {"title": "Failed Logins by IP", "udm": "metadata.product_event_type = \\"4625\\" | group_by principal.ip | count() | sort desc | limit 20", "viz_type": "BAR_CHART"},
    {"title": "Malware Detections", "udm": "metadata.log_type = \\"EDR\\" AND security_result.action = \\"BLOCK\\" | fields metadata.event_timestamp, principal.hostname, target.file.full_path, security_result.threat_name | sort desc metadata.event_timestamp", "viz_type": "TABLE"}
  ],
  "secops_json": {
    "dashboard": {
      "name": "security_operations_center",
      "displayName": "Security Operations Center",
      "panels": [
        {"title": "Failed Logins by IP", "query": "metadata.product_event_type = \\"4625\\" | group_by principal.ip | count() | sort desc | limit 20", "visualization": "BAR_CHART", "timeRange": "LAST_24_HOURS"},
        {"title": "Malware Detections", "query": "metadata.log_type = \\"EDR\\" AND security_result.action = \\"BLOCK\\"", "visualization": "TABLE", "timeRange": "LAST_7_DAYS"}
      ]
    }
  },
  "migration_notes": [
    "Panel 1: stats count by src_ip → group_by principal.ip + count()",
    "Panel 2: action=blocked → security_result.action = BLOCK",
    "Chart panel → BAR_CHART in SecOps; table panel → TABLE",
    "WINEVTLOG and EDR log sources must be ingested in Chronicle"
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
#  Prompt builders
# ─────────────────────────────────────────────────────────────────────────────

ALERT_TASK = """\
Now migrate the following Splunk alert using the pre-analyzed context below.
Use the exact UDM field names provided. Follow the same JSON structure as the examples.
Return ONLY the JSON object — no text before or after.

{context}

RAW INPUT (for reference):
{raw_input}

Return the JSON object now:"""

DASHBOARD_TASK = """\
Now migrate the following Splunk dashboard using the pre-analyzed context below.
Use the exact UDM field names provided. Follow the same JSON structure as the examples.
Return ONLY the JSON object — no text before or after.

{context}

RAW INPUT (for reference):
{raw_input}

Return the JSON object now:"""

RETRY_PROMPT = """\
Your previous response had a JSON error: {error}

Previous response (first 300 chars): {prev_response}

Return ONLY a valid JSON object with these keys: analysis, yaral, udm_query, secops_json, migration_notes.
Start with {{ and end with }}. No markdown."""


# ─────────────────────────────────────────────────────────────────────────────
#  Ollama client
# ─────────────────────────────────────────────────────────────────────────────

async def _call_ollama(prompt: str, system: str = SYSTEM_PROMPT) -> str:
    payload = {
        "model": settings.ollama_model,
        "system": system,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.05,   # very low — we want deterministic JSON
            "num_predict": 2048,
            "repeat_penalty": 1.1,
            "stop": ["```", "==="],
        },
    }
    async with httpx.AsyncClient(timeout=settings.ollama_timeout) as client:
        try:
            resp = await client.post(f"{settings.ollama_base_url}/api/generate", json=payload)
            resp.raise_for_status()
        except httpx.ConnectError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {settings.ollama_base_url}. "
                "Run: ollama serve"
            )
        except httpx.TimeoutException:
            raise RuntimeError(
                f"Ollama timed out after {settings.ollama_timeout}s. "
                f"Try a smaller model or set OLLAMA_TIMEOUT=600 in .env."
            )
    return resp.json().get("response", "")


# ─────────────────────────────────────────────────────────────────────────────
#  JSON extraction + validation
# ─────────────────────────────────────────────────────────────────────────────

def _extract_json(text: str) -> Dict[str, Any]:
    """Robustly extract JSON from LLM output."""
    text = re.sub(r"```json\s*", "", text)
    text = re.sub(r"```\s*", "", text).strip()

    # Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Find first balanced { }
    start = text.find("{")
    if start == -1:
        raise ValueError("No JSON object in response")
    depth, end = 0, start
    for i, ch in enumerate(text[start:], start):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    candidate = text[start:end]
    try:
        return json.loads(candidate)
    except json.JSONDecodeError as e:
        # Try fixing unescaped newlines in strings
        fixed = re.sub(r'(?<!\\)\n(?=[^"]*"(?:[^"\\]|\\.)*")', r'\\n', candidate)
        try:
            return json.loads(fixed)
        except json.JSONDecodeError:
            raise ValueError(f"JSON parse failed: {e} | Raw: {text[:400]}")


def _validate_output(data: Dict[str, Any], migration_type: str) -> Optional[str]:
    """
    Validate required keys exist. Returns error string or None if valid.
    """
    required = ["analysis", "yaral", "secops_json", "migration_notes"]
    missing = [k for k in required if k not in data]
    if missing:
        return f"Missing required keys: {missing}"
    if not data.get("yaral", "").strip():
        return "yaral field is empty"
    if "rule " not in data.get("yaral", ""):
        return "yaral does not contain a valid rule definition"
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Main migration function
# ─────────────────────────────────────────────────────────────────────────────

async def migrate_with_ai(content: str, migration_type: str) -> Dict[str, Any]:
    """
    Full pipeline:
    1. Pre-process (parse + extract field mappings deterministically)
    2. Build few-shot prompt with injected context
    3. Call LLM
    4. Validate output — retry once if invalid
    5. Merge preprocessor warnings into migration_notes
    """
    is_alert = migration_type == "alert"

    # ── Step 1: Pre-process ───────────────────────────────────────────────
    if is_alert:
        parsed = parse_alert(content)
        context = build_alert_context(parsed)
        few_shots = FEW_SHOT_ALERT
        task_template = ALERT_TASK
        preprocessor_warnings = parsed.warnings
    else:
        parsed = parse_dashboard(content)
        context = build_dashboard_context(parsed)
        few_shots = FEW_SHOT_DASHBOARD
        task_template = DASHBOARD_TASK
        preprocessor_warnings = parsed.warnings

    # ── Step 2: Build prompt ──────────────────────────────────────────────
    task = task_template.format(
        context=context,
        raw_input=content[:2000],
    )
    full_prompt = few_shots + "\n\n" + task

    # ── Step 3: Call LLM ──────────────────────────────────────────────────
    raw = await _call_ollama(full_prompt)

    if not raw.strip():
        raise ValueError(
            f"Ollama returned empty response. "
            f"Is model '{settings.ollama_model}' pulled? Run: ollama pull {settings.ollama_model}"
        )

    # ── Step 4: Parse + validate, retry once ─────────────────────────────
    try:
        result = _extract_json(raw)
        err = _validate_output(result, migration_type)
        if err:
            raise ValueError(err)
    except ValueError as first_err:
        # Retry with error context
        retry_prompt = RETRY_PROMPT.format(
            error=str(first_err),
            prev_response=raw[:300],
        )
        raw2 = await _call_ollama(retry_prompt)
        try:
            result = _extract_json(raw2)
        except ValueError as second_err:
            raise ValueError(
                f"Migration failed after retry.\n"
                f"First error: {first_err}\n"
                f"Second error: {second_err}\n"
                f"Try a larger/better model (e.g. mistral or qwen2.5-coder) for complex inputs."
            )

    # ── Step 5: Enrich with preprocessor intelligence ────────────────────
    # Merge warnings
    existing_notes = result.get("migration_notes", [])
    all_notes = list(existing_notes) + [f"⚠ {w}" for w in preprocessor_warnings]
    result["migration_notes"] = all_notes

    # Attach preprocessor metadata
    result["_preprocessor"] = {
        "udm_field_mappings": (parsed.udm_field_mappings if is_alert else {}),
        "unmapped_fields": (parsed.unmapped_fields if is_alert else []),
        "log_types": (parsed.log_types if is_alert else []),
        "spl_to_udm_reference": dict(list(SPL_TO_UDM.items())[:20]),
    }

    return result


def build_migration_response(result: Dict[str, Any], migration_type: str, record_id: str) -> Dict[str, Any]:
    now = datetime.utcnow().isoformat()
    return {
        "id": record_id,
        "migration_type": migration_type,
        "status": "success",
        "analysis": result.get("analysis", {}),
        "yaral": result.get("yaral", ""),
        "udm_query": result.get("udm_query"),
        "udm_queries": result.get("udm_queries"),
        "secops_json": result.get("secops_json", {}),
        "migration_notes": result.get("migration_notes", []),
        "preprocessor": result.get("_preprocessor", {}),
        "created_at": now,
    }
