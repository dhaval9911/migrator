"""
Splunk Input Pre-Processor
--------------------------
Cleans and normalizes messy customer Splunk input before it hits the LLM.
Handles: .conf stanzas, raw SPL, XML dashboards, partial/incomplete input,
comments, extra whitespace, mixed formats, encoding issues.
"""

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# ─────────────────────────────────────────────────────────────────────────────
#  SPL Field → Chronicle UDM Field Mapping
#  This is the core "expertise" injected deterministically (no LLM needed)
# ─────────────────────────────────────────────────────────────────────────────

SPL_TO_UDM: dict = {
    # Network
    "src_ip":           "principal.ip",
    "src":              "principal.ip",
    "src_port":         "principal.port",
    "dest_ip":          "target.ip",
    "dest":             "target.ip",
    "dst_ip":           "target.ip",
    "dest_port":        "target.port",
    "dst_port":         "target.port",
    "src_mac":          "principal.mac",
    "dest_mac":         "target.mac",
    "src_hostname":     "principal.hostname",
    "dest_hostname":    "target.hostname",
    "src_host":         "principal.hostname",
    "dest_host":        "target.hostname",
    "transport":        "network.ip_protocol",
    "protocol":         "network.ip_protocol",
    "bytes_in":         "network.received_bytes",
    "bytes_out":        "network.sent_bytes",
    "bytes":            "network.received_bytes",
    "url":              "target.url",
    "uri":              "target.url",
    "uri_path":         "target.url",
    "http_method":      "network.http.method",
    "http_referrer":    "network.http.referral_url",
    "http_user_agent":  "network.http.user_agent",
    "user_agent":       "network.http.user_agent",
    "status_code":      "network.http.response_code",
    # Identity
    "user":             "principal.user.userid",
    "username":         "principal.user.userid",
    "src_user":         "principal.user.userid",
    "dest_user":        "target.user.userid",
    "user_id":          "principal.user.userid",
    "uid":              "principal.user.userid",
    "email":            "principal.user.email_addresses",
    "src_email":        "principal.user.email_addresses",
    # Host / Endpoint
    "host":             "principal.hostname",
    "hostname":         "principal.hostname",
    "computer_name":    "principal.hostname",
    "ComputerName":     "principal.hostname",
    "dvc":              "principal.hostname",
    "dvc_ip":           "principal.ip",
    "os":               "principal.platform",
    "process":          "target.process.command_line",
    "process_name":     "target.process.file.full_path",
    "parent_process":   "target.process.parent_process.command_line",
    "process_id":       "target.process.pid",
    "pid":              "target.process.pid",
    "ppid":             "target.process.parent_process.pid",
    "file_name":        "target.file.full_path",
    "file_path":        "target.file.full_path",
    "file_hash":        "target.file.sha256",
    "md5":              "target.file.md5",
    "sha256":           "target.file.sha256",
    "sha1":             "target.file.sha1",
    # Windows Events
    "EventCode":        "metadata.product_event_type",
    "EventID":          "metadata.product_event_type",
    "event_id":         "metadata.product_event_type",
    "Account_Name":     "principal.user.userid",
    "Logon_Type":       "extensions.auth.auth_details",
    "SubjectUserName":  "principal.user.userid",
    "TargetUserName":   "target.user.userid",
    "FailureReason":    "security_result.description",
    "IpAddress":        "principal.ip",
    "WorkstationName":  "principal.hostname",
    # Auth / Security
    "action":           "security_result.action",
    "result":           "security_result.action",
    "severity":         "security_result.severity",
    "threat_name":      "security_result.threat_name",
    "signature":        "security_result.rule_name",
    "category":         "security_result.category_details",
    "message":          "security_result.description",
    "reason":           "security_result.description",
    # Metadata
    "sourcetype":       "metadata.log_type",
    "source":           "metadata.product_name",
    "index":            None,   # No UDM equivalent — note this
    "_time":            "metadata.event_timestamp",
    "app":              "principal.application",
    "vendor_product":   "metadata.vendor_name",
}

# SPL command → UDM/YARA-L equivalent hints
SPL_COMMAND_HINTS: dict = {
    "stats count by":       "group_by + count()",
    "stats dc by":          "group_by + count_distinct()",
    "stats sum by":         "group_by + sum()",
    "stats avg by":         "group_by + avg()",
    "stats max by":         "group_by + max()",
    "timechart count":      "group_by + bucket(metadata.event_timestamp)",
    "where count >":        "YARA-L condition: #e > N  or  use match over window",
    "where count >=":       "YARA-L condition: #e >= N",
    "eval":                 "UDM: computed fields not directly supported — encode in condition",
    "rex":                  "UDM: use re.capture() or metadata fields",
    "lookup":               "UDM: use reference lists or threat intel lookups in SecOps",
    "table":                "UDM: use select fields in query projection",
    "dedup":                "UDM: group_by provides distinct values",
    "join":                 "UDM: use correlated events in YARA-L multi-event rules",
    "transaction":          "YARA-L: model as multi-event match over time window",
    "inputlookup":          "SecOps: replace with Reference Lists",
    "outputlookup":         "SecOps: not directly supported — export results",
    "tstats":               "UDM: direct event query (tstats is already optimized like UDM)",
}

# Index → UDM log_type mapping hints
INDEX_TO_LOG_TYPE: dict = {
    "security":         "WINEVTLOG",
    "windows":          "WINEVTLOG",
    "wineventlog":      "WINEVTLOG",
    "linux":            "SYSLOG",
    "syslog":           "SYSLOG",
    "network":          "FIREWALL",
    "firewall":         "FIREWALL",
    "proxy":            "PROXY",
    "web":              "WEBPROXY",
    "dns":              "DNS",
    "endpoint":         "EDR",
    "edr":              "EDR",
    "antivirus":        "ANTIVIRUS",
    "av":               "ANTIVIRUS",
    "email":            "EMAIL",
    "cloud":            "CLOUD_AUDIT",
    "aws":              "AWS_CLOUDTRAIL",
    "azure":            "AZURE_ACTIVITY",
    "gcp":              "GCP_CLOUDAUDIT",
    "o365":             "OFFICE_365",
    "okta":             "OKTA",
    "auth":             "AUTH",
    "authentication":   "AUTH",
    "vpn":              "VPN",
    "ids":              "IDS",
    "ips":              "IDS",
}

# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ParsedSplunkAlert:
    """Structured representation of a Splunk alert/saved search."""
    raw_input: str
    name: str = ""
    spl_query: str = ""
    earliest: str = ""
    latest: str = ""
    cron_schedule: str = ""
    alert_threshold: str = ""
    alert_condition: str = ""
    description: str = ""
    severity: str = "medium"
    # Extracted intelligence
    extracted_fields: List[str] = field(default_factory=list)
    udm_field_mappings: dict = field(default_factory=dict)
    unmapped_fields: List[str] = field(default_factory=list)
    detected_indexes: List[str] = field(default_factory=list)
    log_types: List[str] = field(default_factory=list)
    spl_commands: List[str] = field(default_factory=list)
    command_hints: List[str] = field(default_factory=list)
    threshold_value: Optional[int] = None
    time_window_minutes: Optional[int] = None
    is_aggregation: bool = False
    warnings: List[str] = field(default_factory=list)


@dataclass
class ParsedDashboardPanel:
    title: str
    spl_query: str
    viz_type: str  # chart, table, single, map
    earliest: str = ""
    udm_field_mappings: dict = field(default_factory=dict)
    command_hints: List[str] = field(default_factory=list)


@dataclass
class ParsedSplunkDashboard:
    raw_input: str
    title: str = ""
    panels: List[ParsedDashboardPanel] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _normalize_text(text: str) -> str:
    """Strip BOM, normalize line endings, strip trailing whitespace."""
    text = text.strip().lstrip("\ufeff")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Remove inline Splunk comments (lines starting with #)
    lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#") and not stripped.startswith("#!"):
            continue  # drop comment-only lines
        lines.append(line)
    return "\n".join(lines).strip()


def _extract_spl_fields(spl: str) -> Tuple[List[str], List[str]]:
    """Extract field names referenced in SPL. Returns (found_fields, unknown_fields)."""
    # Common SPL field patterns
    field_patterns = [
        r'\bby\s+([\w,\s]+?)(?:\s*\||$)',       # stats ... by field1, field2
        r'\bwhere\s+(\w+)\s*[=><]',              # where field = value
        r'\beval\s+(\w+)\s*=',                   # eval newfield =
        r'\btable\s+([\w,\s]+?)(?:\s*\||$)',     # table field1, field2
        r'\brex\s+field=(\w+)',                  # rex field=fieldname
        r'\b(\w+)=\*',                           # fieldname=*
        r'"(\w+)"',                              # "fieldname" in searches
    ]
    found = set()
    for pat in field_patterns:
        for match in re.finditer(pat, spl, re.IGNORECASE):
            for f in re.split(r'[,\s]+', match.group(1).strip()):
                f = f.strip()
                if f and not f.lower() in ('as', 'by', 'from', 'where', 'and', 'or', 'not'):
                    found.add(f)

    # Also find bare field=value patterns
    for match in re.finditer(r'(?<!\w)(\w+)=(?!"?\*)"?[\w\d._-]+', spl):
        found.add(match.group(1))

    known = [f for f in found if f in SPL_TO_UDM]
    unknown = [f for f in found if f not in SPL_TO_UDM and len(f) > 2]
    return known, unknown


def _map_fields(fields: List[str]) -> dict:
    """Return {spl_field: udm_field} for known fields (exclude None mappings)."""
    return {f: SPL_TO_UDM[f] for f in fields if SPL_TO_UDM.get(f) is not None}


def _detect_indexes(spl: str) -> Tuple[List[str], List[str]]:
    """Find index= values and map to UDM log types."""
    indexes = re.findall(r'\bindex\s*=\s*"?(\w+)"?', spl, re.IGNORECASE)
    log_types = []
    for idx in indexes:
        for key, lt in INDEX_TO_LOG_TYPE.items():
            if key in idx.lower():
                log_types.append(lt)
                break
    return indexes, list(set(log_types))


def _detect_commands(spl: str) -> Tuple[List[str], List[str]]:
    """Identify SPL commands present and return migration hints."""
    found_commands = []
    hints = []
    for cmd, hint in SPL_COMMAND_HINTS.items():
        if cmd.lower() in spl.lower():
            found_commands.append(cmd)
            hints.append(f"SPL `{cmd}` → {hint}")
    return found_commands, hints


def _extract_threshold(spl: str) -> Optional[int]:
    """Try to extract numeric thresholds from where/having clauses."""
    match = re.search(r'(?:where|having)\s+\w+\s*[><=]+\s*(\d+)', spl, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def _extract_time_window(earliest: str) -> Optional[int]:
    """Convert Splunk time modifiers to minutes."""
    if not earliest:
        return None
    match = re.match(r'-(\d+)([mhd])@?', earliest.strip())
    if not match:
        return None
    val, unit = int(match.group(1)), match.group(2)
    return val if unit == 'm' else val * 60 if unit == 'h' else val * 1440


def _infer_severity(text: str) -> str:
    text_lower = text.lower()
    if any(w in text_lower for w in ['critical', 'crit', 'emergency', 'ransomware', 'exfil']):
        return 'critical'
    if any(w in text_lower for w in ['high', 'brute.force', 'lateral', 'privilege', 'admin', 'malware']):
        return 'high'
    if any(w in text_lower for w in ['medium', 'suspicious', 'anomal', 'unusual']):
        return 'medium'
    if any(w in text_lower for w in ['low', 'info', 'informational']):
        return 'low'
    return 'medium'


# ─── Alert Parser ─────────────────────────────────────────────────────────────

def parse_alert(raw: str) -> ParsedSplunkAlert:
    """
    Parse messy Splunk alert input into a clean structured object.
    Handles: .conf stanzas, raw SPL, partial configs, mixed formats.
    """
    text = _normalize_text(raw)
    result = ParsedSplunkAlert(raw_input=text)

    # ── Detect format ─────────────────────────────────────────────────────
    is_conf = bool(re.search(r'^\[.+\]', text, re.MULTILINE))
    is_spl_only = not is_conf and ('|' in text or 'index=' in text.lower() or 'search' in text.lower())

    if is_conf:
        # Parse .conf stanza format
        stanza = re.search(r'^\[(.+?)\]', text, re.MULTILINE)
        if stanza:
            result.name = stanza.group(1).strip()

        def _conf_val(key: str) -> str:
            m = re.search(rf'^\s*{key}\s*=\s*(.+?)$', text, re.MULTILINE | re.IGNORECASE)
            return m.group(1).strip() if m else ""

        result.spl_query = _conf_val('search') or _conf_val('query')
        result.earliest = _conf_val('dispatch.earliest_time') or _conf_val('earliest_time')
        result.latest = _conf_val('dispatch.latest_time') or _conf_val('latest_time')
        result.cron_schedule = _conf_val('cron_schedule')
        result.alert_threshold = _conf_val('alert.threshold') or _conf_val('threshold')
        result.alert_condition = _conf_val('alert.condition') or _conf_val('condition')
        result.description = _conf_val('description') or _conf_val('action.email.subject')
        alert_severity = _conf_val('alert.severity') or _conf_val('severity')
        result.severity = alert_severity if alert_severity else _infer_severity(text)

    elif is_spl_only:
        # Treat entire input as raw SPL
        result.name = "migrated_alert"
        result.spl_query = text
        result.severity = _infer_severity(text)
        result.warnings.append("Input appears to be raw SPL — no .conf metadata found. Defaults applied.")

    else:
        # Unknown format — pass to LLM as-is but warn
        result.name = "migrated_alert"
        result.spl_query = text
        result.warnings.append("Input format not recognized as .conf or SPL. Attempting best-effort migration.")

    # ── Enrich extracted SPL ──────────────────────────────────────────────
    spl = result.spl_query or text
    known_fields, unknown_fields = _extract_spl_fields(spl)
    result.extracted_fields = known_fields
    result.udm_field_mappings = _map_fields(known_fields)
    result.unmapped_fields = unknown_fields
    result.detected_indexes, result.log_types = _detect_indexes(spl)
    result.spl_commands, result.command_hints = _detect_commands(spl)
    result.threshold_value = _extract_threshold(spl)
    result.time_window_minutes = _extract_time_window(result.earliest)
    result.is_aggregation = any(c in spl.lower() for c in ['stats', 'tstats', 'timechart', 'chart'])

    # ── Warnings for unmapped fields ──────────────────────────────────────
    if result.unmapped_fields:
        result.warnings.append(
            f"Fields without UDM mapping (manual review needed): {', '.join(result.unmapped_fields[:8])}"
        )
    if result.detected_indexes and not result.log_types:
        result.warnings.append(
            f"Index '{result.detected_indexes[0]}' has no known UDM log type — verify ingestion in SecOps."
        )
    if 'lookup' in spl.lower():
        result.warnings.append("SPL lookup detected — replace with SecOps Reference Lists or Threat Intel lookups.")
    if 'transaction' in spl.lower():
        result.warnings.append("SPL transaction command → model as YARA-L multi-event rule with match..over window.")

    return result


# ─── Dashboard Parser ─────────────────────────────────────────────────────────

def parse_dashboard(raw: str) -> ParsedSplunkDashboard:
    """
    Parse Splunk Simple XML dashboard into structured panels.
    Handles malformed XML, missing tags, mixed content.
    """
    text = _normalize_text(raw)
    result = ParsedSplunkDashboard(raw_input=text)

    # Try proper XML parse first
    try:
        # Wrap in root if needed
        xml_text = text
        if not text.strip().startswith('<?xml') and not text.strip().startswith('<dashboard'):
            xml_text = f"<dashboard>{text}</dashboard>"

        root = ET.fromstring(xml_text)

        # Title
        label = root.find('.//label')
        result.title = label.text.strip() if label is not None and label.text else "Migrated Dashboard"

        # Find all panels
        for panel in root.findall('.//panel'):
            p_title_el = panel.find('title')
            p_title = p_title_el.text.strip() if p_title_el is not None and p_title_el.text else "Untitled Panel"

            # Determine viz type
            viz = "table"
            if panel.find('chart') is not None:
                viz = "chart"
            elif panel.find('single') is not None:
                viz = "single"
            elif panel.find('map') is not None:
                viz = "map"
            elif panel.find('event') is not None:
                viz = "events"

            # Extract query
            query_el = panel.find('.//query')
            earliest_el = panel.find('.//earliest')
            spl = query_el.text.strip() if query_el is not None and query_el.text else ""
            earliest = earliest_el.text.strip() if earliest_el is not None and earliest_el.text else ""

            if not spl:
                continue  # skip empty panels

            known, _ = _extract_spl_fields(spl)
            _, hints = _detect_commands(spl)

            result.panels.append(ParsedDashboardPanel(
                title=p_title,
                spl_query=spl,
                viz_type=viz,
                earliest=earliest,
                udm_field_mappings=_map_fields(known),
                command_hints=hints,
            ))

    except ET.ParseError as xml_err:
        result.warnings.append(f"XML parse error ({xml_err}) — falling back to regex extraction.")
        # Regex fallback for malformed XML
        queries = re.findall(r'<query>(.*?)</query>', text, re.DOTALL)
        titles = re.findall(r'<title>(.*?)</title>', text, re.DOTALL)
        label_match = re.search(r'<label>(.*?)</label>', text, re.DOTALL)
        result.title = label_match.group(1).strip() if label_match else "Migrated Dashboard"

        for i, spl in enumerate(queries):
            spl = spl.strip()
            title = titles[i + 1].strip() if i + 1 < len(titles) else f"Panel {i+1}"
            known, _ = _extract_spl_fields(spl)
            _, hints = _detect_commands(spl)
            result.panels.append(ParsedDashboardPanel(
                title=title, spl_query=spl, viz_type="table",
                udm_field_mappings=_map_fields(known), command_hints=hints,
            ))

    if not result.panels:
        result.warnings.append("No panels found in dashboard. Treating full input as single query.")
        known, _ = _extract_spl_fields(text)
        _, hints = _detect_commands(text)
        result.panels.append(ParsedDashboardPanel(
            title="Main Panel", spl_query=text, viz_type="table",
            udm_field_mappings=_map_fields(known), command_hints=hints,
        ))

    return result


# ─── Context builder (injected into LLM prompt) ──────────────────────────────

def build_alert_context(parsed: ParsedSplunkAlert) -> str:
    """Build a rich, structured context block to prepend to the LLM prompt."""
    lines = ["=== PRE-ANALYZED SPLUNK ALERT ==="]

    if parsed.name:
        lines.append(f"NAME: {parsed.name}")
    if parsed.spl_query:
        lines.append(f"SPL QUERY:\n  {parsed.spl_query}")
    if parsed.description:
        lines.append(f"DESCRIPTION: {parsed.description}")
    lines.append(f"SEVERITY: {parsed.severity.upper()}")

    if parsed.time_window_minutes:
        lines.append(f"TIME WINDOW: {parsed.time_window_minutes} minutes")
    if parsed.threshold_value:
        lines.append(f"THRESHOLD: count > {parsed.threshold_value}")
    if parsed.cron_schedule:
        lines.append(f"SCHEDULE: {parsed.cron_schedule}")
    if parsed.is_aggregation:
        lines.append("TYPE: Aggregation/count-based detection → use YARA-L match..over..condition with #e")

    if parsed.udm_field_mappings:
        lines.append("\nFIELD MAPPINGS (use these exact UDM fields):")
        for spl_f, udm_f in parsed.udm_field_mappings.items():
            lines.append(f"  {spl_f} → {udm_f}")

    if parsed.unmapped_fields:
        lines.append(f"\nUNMAPPED FIELDS (best-effort mapping needed): {', '.join(parsed.unmapped_fields[:6])}")

    if parsed.log_types:
        lines.append(f"\nUDM LOG TYPE(S): {', '.join(parsed.log_types)}")
    elif parsed.detected_indexes:
        lines.append(f"\nSPL INDEX: {', '.join(parsed.detected_indexes)} (map to appropriate UDM log type)")

    if parsed.command_hints:
        lines.append("\nSPL COMMAND TRANSLATIONS:")
        for hint in parsed.command_hints:
            lines.append(f"  • {hint}")

    if parsed.warnings:
        lines.append("\nWARNINGS:")
        for w in parsed.warnings:
            lines.append(f"  ⚠ {w}")

    lines.append("=================================\n")
    return "\n".join(lines)


def build_dashboard_context(parsed: ParsedSplunkDashboard) -> str:
    lines = [f"=== PRE-ANALYZED SPLUNK DASHBOARD: {parsed.title} ==="]
    lines.append(f"PANEL COUNT: {len(parsed.panels)}")

    for i, panel in enumerate(parsed.panels):
        lines.append(f"\nPANEL {i+1}: {panel.title}")
        lines.append(f"  VIZ TYPE: {panel.viz_type}")
        lines.append(f"  SPL: {panel.spl_query[:300]}")
        if panel.udm_field_mappings:
            lines.append("  UDM FIELD MAPPINGS:")
            for k, v in panel.udm_field_mappings.items():
                lines.append(f"    {k} → {v}")
        if panel.command_hints:
            for h in panel.command_hints:
                lines.append(f"  • {h}")

    if parsed.warnings:
        lines.append("\nWARNINGS:")
        for w in parsed.warnings:
            lines.append(f"  ⚠ {w}")

    lines.append("=================================\n")
    return "\n".join(lines)
