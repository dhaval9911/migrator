from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime


class MigrationType(str, Enum):
    alert = "alert"
    dashboard = "dashboard"


class MigrateRequest(BaseModel):
    content: str = Field(..., description="Raw Splunk content (SPL, XML, .conf)")
    migration_type: MigrationType = Field(..., description="Type of Splunk content")
    name: Optional[str] = Field(None, description="Optional name for the migration")


class AnalysisResult(BaseModel):
    type: str
    detection_logic: Optional[str] = None
    splunk_search: Optional[str] = None
    severity: Optional[str] = None
    data_sources: Optional[List[str]] = None
    title: Optional[str] = None
    panel_count: Optional[int] = None
    panels: Optional[List[Dict[str, Any]]] = None


class MigrateResponse(BaseModel):
    id: str
    migration_type: str
    status: str
    analysis: AnalysisResult
    yaral: str
    udm_query: Optional[str] = None
    udm_queries: Optional[List[Dict[str, str]]] = None
    secops_json: Dict[str, Any]
    migration_notes: List[str]
    created_at: str


class BatchMigrateRequest(BaseModel):
    items: List[MigrateRequest]


class BatchMigrateResponse(BaseModel):
    batch_id: str
    total: int
    succeeded: int
    failed: int
    results: List[Dict[str, Any]]
    created_at: str


class HistoryItem(BaseModel):
    id: str
    name: Optional[str]
    migration_type: str
    snippet: str
    status: str
    severity: Optional[str]
    created_at: str


class HistoryResponse(BaseModel):
    items: List[HistoryItem]
    total: int
