from sqlalchemy import create_engine, Column, String, Text, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import uuid

from app.core.config import settings

engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False}  # needed for SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class MigrationRecord(Base):
    __tablename__ = "migrations"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=True)
    migration_type = Column(String, nullable=False)
    original_content = Column(Text, nullable=False)
    snippet = Column(String, nullable=True)
    status = Column(String, default="success")
    severity = Column(String, nullable=True)
    yaral = Column(Text, nullable=True)
    udm_query = Column(Text, nullable=True)
    secops_json = Column(JSON, nullable=True)
    analysis = Column(JSON, nullable=True)
    migration_notes = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
