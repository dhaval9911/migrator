from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Ollama (local, free, no API key)
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "mistral"      # change to llama3, gemma2, etc.
    ollama_timeout: int = 300          # seconds — CPU inference is slow

    # App
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    debug: bool = True

    # Storage (SQLite for local use)
    database_url: str = "sqlite:///./migrations.db"

    # Optional: Google SecOps / Chronicle
    chronicle_api_key: Optional[str] = None
    chronicle_customer_id: Optional[str] = None
    chronicle_region: str = "us"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
