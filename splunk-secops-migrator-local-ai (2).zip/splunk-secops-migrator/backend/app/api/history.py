from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db, MigrationRecord

router = APIRouter()


@router.get("/")
async def get_history(
    db: Session = Depends(get_db),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
    migration_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
):
    """Get migration history with optional filtering."""
    query = db.query(MigrationRecord)

    if migration_type:
        query = query.filter(MigrationRecord.migration_type == migration_type)
    if status:
        query = query.filter(MigrationRecord.status == status)

    total = query.count()
    records = query.order_by(MigrationRecord.created_at.desc()).offset(offset).limit(limit).all()

    items = [
        {
            "id": r.id,
            "name": r.name,
            "migration_type": r.migration_type,
            "snippet": r.snippet,
            "status": r.status,
            "severity": r.severity,
            "created_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in records
    ]

    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/{migration_id}")
async def get_migration(migration_id: str, db: Session = Depends(get_db)):
    """Get full details of a specific migration."""
    record = db.query(MigrationRecord).filter(MigrationRecord.id == migration_id).first()
    if not record:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Migration not found")

    return {
        "id": record.id,
        "name": record.name,
        "migration_type": record.migration_type,
        "original_content": record.original_content,
        "status": record.status,
        "severity": record.severity,
        "yaral": record.yaral,
        "udm_query": record.udm_query,
        "secops_json": record.secops_json,
        "analysis": record.analysis,
        "migration_notes": record.migration_notes,
        "created_at": record.created_at.isoformat() if record.created_at else None,
    }


@router.delete("/{migration_id}")
async def delete_migration(migration_id: str, db: Session = Depends(get_db)):
    """Delete a migration record."""
    record = db.query(MigrationRecord).filter(MigrationRecord.id == migration_id).first()
    if not record:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Migration not found")

    db.delete(record)
    db.commit()
    return {"deleted": True, "id": migration_id}


@router.get("/export/all")
async def export_all(db: Session = Depends(get_db)):
    """Export all successful migrations as JSON."""
    records = db.query(MigrationRecord).filter(MigrationRecord.status == "success").all()
    return {
        "count": len(records),
        "migrations": [
            {
                "id": r.id,
                "name": r.name,
                "type": r.migration_type,
                "yaral": r.yaral,
                "udm_query": r.udm_query,
                "secops_json": r.secops_json,
                "migration_notes": r.migration_notes,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in records
        ],
    }
