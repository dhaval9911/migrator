from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
import uuid
import asyncio
from datetime import datetime

from app.models.schemas import BatchMigrateRequest
from app.services.ai_service import migrate_with_ai, build_migration_response
from app.core.database import get_db, MigrationRecord

router = APIRouter()


@router.post("/")
async def batch_migrate(request: BatchMigrateRequest, db: Session = Depends(get_db)):
    """
    Migrate multiple Splunk items in one request.
    Processes up to 20 items concurrently (rate-limit safe).
    """
    if not request.items:
        raise HTTPException(status_code=400, detail="No items provided")
    if len(request.items) > 20:
        raise HTTPException(status_code=400, detail="Maximum 20 items per batch")

    batch_id = str(uuid.uuid4())
    results = []
    succeeded = 0
    failed = 0

    # Process with small concurrency to avoid rate limits
    semaphore = asyncio.Semaphore(3)

    async def process_item(item, index):
        async with semaphore:
            record_id = str(uuid.uuid4())
            try:
                ai_result = await migrate_with_ai(item.content, item.migration_type.value)
                response = build_migration_response(ai_result, item.migration_type.value, record_id)

                analysis = ai_result.get("analysis", {})
                record = MigrationRecord(
                    id=record_id,
                    name=item.name or f"batch-{batch_id[:8]}-item-{index+1}",
                    migration_type=item.migration_type.value,
                    original_content=item.content,
                    snippet=item.content[:120].replace("\n", " "),
                    status="success",
                    severity=analysis.get("severity"),
                    yaral=ai_result.get("yaral"),
                    udm_query=ai_result.get("udm_query") or str(ai_result.get("udm_queries", "")),
                    secops_json=ai_result.get("secops_json"),
                    analysis=analysis,
                    migration_notes=ai_result.get("migration_notes", []),
                )
                db.add(record)
                return {"index": index, "status": "success", "data": response}

            except Exception as e:
                record = MigrationRecord(
                    id=record_id,
                    name=item.name or f"batch-{batch_id[:8]}-item-{index+1}",
                    migration_type=item.migration_type.value,
                    original_content=item.content,
                    snippet=item.content[:120].replace("\n", " "),
                    status="failed",
                )
                db.add(record)
                return {"index": index, "status": "failed", "error": str(e)}

    tasks = [process_item(item, i) for i, item in enumerate(request.items)]
    raw_results = await asyncio.gather(*tasks, return_exceptions=True)

    db.commit()

    for r in raw_results:
        if isinstance(r, Exception):
            results.append({"status": "failed", "error": str(r)})
            failed += 1
        elif r["status"] == "success":
            results.append(r)
            succeeded += 1
        else:
            results.append(r)
            failed += 1

    return {
        "batch_id": batch_id,
        "total": len(request.items),
        "succeeded": succeeded,
        "failed": failed,
        "results": results,
        "created_at": datetime.utcnow().isoformat(),
    }
