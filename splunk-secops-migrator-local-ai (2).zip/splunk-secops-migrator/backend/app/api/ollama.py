from fastapi import APIRouter
import httpx
from app.core.config import settings

router = APIRouter()


@router.get("/status")
async def ollama_status():
    """Check if Ollama is running and return available models."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [m["name"] for m in data.get("models", [])]
            return {
                "running": True,
                "base_url": settings.ollama_base_url,
                "active_model": settings.ollama_model,
                "available_models": models,
                "model_ready": settings.ollama_model in models or
                               any(settings.ollama_model in m for m in models),
            }
    except Exception as e:
        return {
            "running": False,
            "base_url": settings.ollama_base_url,
            "active_model": settings.ollama_model,
            "available_models": [],
            "model_ready": False,
            "error": str(e),
        }


@router.get("/models")
async def list_models():
    """List all locally available Ollama models."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        return {"error": str(e), "models": []}


RECOMMENDED_MODELS = [
    {
        "name": "mistral",
        "tag": "mistral:latest",
        "size": "4.1 GB",
        "ram": "8 GB",
        "description": "Best balance of speed and quality for structured JSON output",
        "recommended": True,
    },
    {
        "name": "llama3.2",
        "tag": "llama3.2:latest",
        "size": "2.0 GB",
        "ram": "4 GB",
        "description": "Lightweight, fast — good for lower-RAM machines",
        "recommended": False,
    },
    {
        "name": "llama3.1",
        "tag": "llama3.1:latest",
        "size": "4.7 GB",
        "ram": "8 GB",
        "description": "Meta Llama 3.1 — strong reasoning, good JSON compliance",
        "recommended": False,
    },
    {
        "name": "gemma2",
        "tag": "gemma2:latest",
        "size": "5.4 GB",
        "ram": "8 GB",
        "description": "Google Gemma 2 — excellent instruction following",
        "recommended": False,
    },
    {
        "name": "qwen2.5-coder",
        "tag": "qwen2.5-coder:latest",
        "size": "4.7 GB",
        "ram": "8 GB",
        "description": "Code-focused model — great for YARA-L and structured output",
        "recommended": False,
    },
    {
        "name": "phi3",
        "tag": "phi3:latest",
        "size": "2.3 GB",
        "ram": "4 GB",
        "description": "Microsoft Phi-3 mini — very fast on CPU, good quality",
        "recommended": False,
    },
]


@router.get("/recommended")
async def recommended_models():
    """Return list of recommended models for this tool."""
    return {"models": RECOMMENDED_MODELS}


@router.get("/field-mappings")
async def get_field_mappings():
    """Return the full SPL → UDM field mapping dictionary."""
    from app.services.preprocessor import SPL_TO_UDM, INDEX_TO_LOG_TYPE, SPL_COMMAND_HINTS
    return {
        "spl_to_udm": {k: v for k, v in SPL_TO_UDM.items() if v is not None},
        "index_to_log_type": INDEX_TO_LOG_TYPE,
        "command_hints": SPL_COMMAND_HINTS,
        "total_mappings": sum(1 for v in SPL_TO_UDM.values() if v is not None),
    }
