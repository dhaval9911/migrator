from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Form
from sqlalchemy.orm import Session
import uuid

from app.models.schemas import MigrateRequest, MigrationType
from app.services.ai_service import migrate_with_ai, build_migration_response
from app.core.database import get_db, MigrationRecord

router = APIRouter()


@router.post("/")
async def migrate_content(request: MigrateRequest, db: Session = Depends(get_db)):
    """
    Migrate Splunk alert or dashboard content to Google SecOps format.
    Accepts raw SPL, .conf text, or XML dashboard content.
    """
    if not request.content.strip():
        raise HTTPException(status_code=400, detail="Content cannot be empty")

    record_id = str(uuid.uuid4())

    try:
        ai_result = await migrate_with_ai(request.content, request.migration_type.value)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI migration failed: {str(e)}")

    response = build_migration_response(ai_result, request.migration_type.value, record_id)

    # Persist to DB
    analysis = ai_result.get("analysis", {})
    record = MigrationRecord(
        id=record_id,
        name=request.name,
        migration_type=request.migration_type.value,
        original_content=request.content,
        snippet=request.content[:120].replace("\n", " "),
        status="success",
        severity=analysis.get("severity"),
        yaral=ai_result.get("yaral"),
        udm_query=ai_result.get("udm_query") or str(ai_result.get("udm_queries", "")),
        secops_json=ai_result.get("secops_json"),
        analysis=analysis,
        migration_notes=ai_result.get("migration_notes", []),
    )
    db.add(record)
    db.commit()

    return response


@router.post("/file")
async def migrate_file(
    file: UploadFile = File(...),
    migration_type: str = Form(...),
    name: str = Form(None),
    db: Session = Depends(get_db),
):
    """
    Upload a .xml, .conf, .spl, or .txt file for migration.
    """
    allowed_types = [
        "text/plain", "text/xml", "application/xml",
        "application/octet-stream", ""
    ]
    if file.content_type not in allowed_types and not file.filename.endswith(
        (".xml", ".conf", ".spl", ".txt")
    ):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use .xml, .conf, .spl, or .txt"
        )

    content = await file.read()
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be UTF-8 encoded text")

    if not text.strip():
        raise HTTPException(status_code=400, detail="File is empty")

    req = MigrateRequest(
        content=text,
        migration_type=MigrationType(migration_type),
        name=name or file.filename,
    )
    return await migrate_content(req, db)
