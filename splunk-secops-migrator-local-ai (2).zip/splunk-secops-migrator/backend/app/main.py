from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from app.api import migrate, health, batch, history, ollama

app = FastAPI(
    title="Splunk → Google SecOps Migrator",
    description="AI-powered migration tool for Splunk dashboards and alerts to Google SecOps",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api", tags=["health"])
app.include_router(migrate.router, prefix="/api/migrate", tags=["migrate"])
app.include_router(batch.router, prefix="/api/batch", tags=["batch"])
app.include_router(history.router, prefix="/api/history", tags=["history"])
app.include_router(ollama.router, prefix="/api/ollama", tags=["ollama"])

# Serve React frontend if built
frontend_dist = os.path.join(os.path.dirname(__file__), "../../frontend/dist")
if os.path.exists(frontend_dist):
    app.mount("/assets", StaticFiles(directory=f"{frontend_dist}/assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_frontend(full_path: str):
        index = os.path.join(frontend_dist, "index.html")
        return FileResponse(index)
